import sys
import os
import copy
import csv
from PyQt5.QtCore import Qt, QUrl, QThread, pyqtSignal, QSize
from PyQt5.QtGui import QIcon, QPixmap, QCursor, QPainter, QFont
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtWidgets import QApplication, QFileDialog, QWidget, QLabel, QSlider, QPushButton, QLineEdit, QTabWidget, \
    QGridLayout, QMessageBox, QComboBox, QProgressBar
from PyQt5.QtMultimedia import QMediaContent, QMediaPlayer
from PyQt5.QtMultimediaWidgets import QVideoWidget

import seaborn as sns
import plotly.express as px
import shutil
import torch
import time
import numpy as np
import cv2
import mmcv
import mmengine
import math
import pandas as pd
from mmdet.apis import init_detector, inference_detector
from mmdet.utils import register_all_modules
from mmdet.registry import VISUALIZERS

import random
import dxfgrabber
import win32com.client
import pythoncom

import json
from train_gui import train_main, train_parser
from test_gui import test_main, test_parse_args  # 生成.pkl文件
from analyze_logs_gui import analyze_logs_main, analyze_logs_parse_args
from eval_pr_curve_gui import plot_pr_curve
from confusion_matrix_gui import confusion_matrix_main, confusion_matrix_parse_args
from visualize_gui import load_data, show_chart
from labelme2coco_gui import labelme_coco_main

import multiprocessing
import base64
# 转化图标
from images.play_png import img as play
from images.pause_png import img as pause
from images.sond_on_png import img as sound_on
from images.sound_off_png import img as sound_off

tmp = open('play.png', 'wb')  # 创建临时的文件
tmp.write(base64.b64decode(play))  ##把这个one图片解码出来，写入文件中去。
tmp.close()

tmp = open('pause.png', 'wb')
tmp.write(base64.b64decode(pause))
tmp.close()

tmp = open('sound_on.png', 'wb')
tmp.write(base64.b64decode(sound_on))
tmp.close()

tmp = open('sound_off.png', 'wb')
tmp.write(base64.b64decode(sound_off))
tmp.close()

pi = math.pi
index_to_class = {'0': 'Point_good', '1': 'Point_bad', '2': 'Staff_bad'}
class_to_palette = {'Point_good': 0, 'Point_bad': 1, 'Staff_bad': 2}
palette = [(220, 20, 60), (119, 11, 32), (0, 0, 142), (0, 0, 230),
               (106, 0, 228), (0, 60, 100), (0, 80, 100), (0, 0, 70),
               (0, 0, 192), (250, 170, 30), (100, 170, 30), (220, 220, 0),
               (175, 116, 175), (250, 0, 30), (165, 42, 42), (255, 77, 255),
               (0, 226, 252), (182, 182, 255), (0, 82, 0), (120, 166, 157),
               (110, 76, 0), (174, 57, 255), (199, 100, 0), (72, 0, 118),
               (255, 179, 240), (0, 125, 92), (209, 0, 151), (188, 208, 182),
               (0, 220, 176), (255, 99, 164), (92, 0, 73), (133, 129, 255),
               (78, 180, 255), (0, 228, 0), (174, 255, 243), (45, 89, 255),
               (134, 134, 103), (145, 148, 174), (255, 208, 186),
               (197, 226, 255), (171, 134, 1), (109, 63, 54), (207, 138, 255),
               (151, 0, 95), (9, 80, 61), (84, 105, 51), (74, 65, 105),
               (166, 196, 102), (208, 195, 210), (255, 109, 65), (0, 143, 149),
               (179, 0, 194), (209, 99, 106), (5, 121, 0), (227, 255, 205),
               (147, 186, 208), (153, 69, 1), (3, 95, 161), (163, 255, 0),
               (119, 0, 170), (0, 182, 199), (0, 165, 120), (183, 130, 88),
               (95, 32, 0), (130, 114, 135), (110, 129, 133), (166, 74, 118),
               (219, 142, 185), (79, 210, 114), (178, 90, 62), (65, 70, 15),
               (127, 167, 115), (59, 105, 106), (142, 108, 45), (196, 172, 0),
               (95, 54, 80), (128, 76, 255), (201, 57, 1), (246, 0, 122),
               (191, 162, 208)]
# sift = cv2.SIFT_create(nfeatures=30, nOctaveLayers=3, contrastThreshold=0.04, edgeThreshold=10, sigma=1.6)
sift = cv2.SIFT_create(nfeatures=30, nOctaveLayers=3, contrastThreshold=0.04, edgeThreshold=10, sigma=1.6)


# 定义求poita夹角函数,镜头顺指针为正，逆时针为负
def angle(pointa_x, pointa_y, pointb_x, pointb_y, pointc_x, pointc_y):
    x1, y1 = pointb_x - pointa_x, pointb_y - pointa_y
    x2, y2 = pointc_x - pointa_x, pointc_y - pointa_y

    angle1 = math.atan2(y1, x1)
    angle1 = angle1 * 180 / math.pi
    if angle1 < 0:
        angle1 = 360 + angle1  # 0-180为正，180-360为负

    angle2 = math.atan2(y2, x2)  # 逆时针
    angle2 = angle2 * 180 / math.pi
    if angle2 < 0:
        angle2 = 360 + angle2

    list = []
    list.append(angle1)
    list.append(angle2)
    if 270 <= list[0] < 360 and 0 <= list[1] < 90:  # 为了判断是否一个1度，一个359度这种情况
        return 360 + list[1] - list[0]
    elif 0 <= list[0] < 90 and 270 <= list[1] < 360:
        return list[1] - 360 - list[0]
    else:
        return list[1] - list[0]


# 通过distance最小的两个点计算角度
def frame_angle(xylist, angle_single_before, con_target_before, img_match, save_path, f, w, angle_th, loss_th):
    if len(xylist) == 1:
        print('\n匹配对为0，返回上一')
        cv2.imwrite(f'{save_path}/{frame_id:06d}.jpg', img_match)
        data = {"errors": "Dmatch is None"}
        json.dump(data, f)
        f.write('\n')
        return angle_single_before, angle_single_before, con_target_before
    elif len(xylist) == 2:
        print('\n匹配对为1，无法计算角度，返回上一')
        data = {"errors": "Dmatch is 1"}
        json.dump(data, f)
        f.write('\n')
        cv2.imwrite(f'{save_path}/{frame_id:06d}.jpg', img_match)
        return angle_single_before, angle_single_before, con_target_before
    else:
        # ['DMatch', 'distance', 'x_keypoint1', 'y_keypoint1', 'response1', 'x_keypoint2', 'y_keypoint2', 'response2']


        xylist_new = [xylist[0]]
        get_id = []
        for i in range(1, len(xylist)):
            loss11 = math.sqrt((xylist[i][5] - xylist[i][2]) ** 2 + (xylist[i][6] - xylist[i][3]) ** 2)
            if loss11 <= loss_th:
                xylist_new.append(xylist[i])
                get_id.append(xylist[i][1])

        tmp = list(map(list, zip(range(1, len(get_id) + 1), get_id)))
        # 从小到大排序
        small = sorted(tmp, key=lambda x: x[1], reverse=False)


        if len(xylist_new) <= 2:
            print('\n100像素过滤后匹配对为1，返回上一')
            cv2.imwrite(f'{save_path}/{frame_id:06d}.jpg', img_match)
            data = {"errors": "Dmatch is None"}
            json.dump(data, f)
            f.write('\n')
            return angle_single_before, angle_single_before, con_target_before
        else:

            # 根据小到大排序前两个索引，获得用于计算角度的两个特征点
            compute_angle = []
            compute_angle.append(xylist_new[0])
            compute_angle.append(xylist_new[small[0][0]])
            compute_angle.append(xylist_new[small[1][0]])
            # print(compute_angle[1])
            # print(compute_angle[2])
            # 计算角度
            a_x = compute_angle[1][2]
            a_y = compute_angle[1][3]
            b_x = compute_angle[2][2]
            b_y = compute_angle[2][3]
            dx = compute_angle[1][5] - compute_angle[1][2]
            dy = compute_angle[1][6] - compute_angle[1][3]
            c_x = compute_angle[2][5] - dx
            c_y = compute_angle[2][6] - dy
            angle1 = -angle(a_x, a_y, b_x, b_y, c_x, c_y)

            con_target = [compute_angle[1][2], compute_angle[1][3], compute_angle[1][5], compute_angle[1][6]]
            if angle_th >= angle1 >= -angle_th:
                return angle1, angle1, con_target
            else:
                # print('两帧角度大于5度，猜测误匹配。返回上一帧角度')
                # cv2.imwrite(f'{save_path}/{frame_id:06d}_{int(angle1)}.jpg', img_match)
                print('\n-----{}-----\n'.format(angle1))
                # print(compute_angle)
                # cv2.imwrite(f'{save_path}/{frame_id:06d}_before.jpg', before_img)
                # cv2.imwrite(f'{save_path}/{frame_id:06d}_now.jpg', img)
                return angle1, angle_single_before, con_target_before

def picture_result(imgname1, imgname2):
    # 图片灰度化

    if isinstance(imgname1, str):
        img1 = cv2.imread(imgname1)
    else:
        img1 = imgname1
    if isinstance(imgname2, str):
        img2 = cv2.imread(imgname2)
    else:
        img2 = imgname2

    scale = 1  # 图片大小会影响匹配对，至少两对才能计算角度
    height, width = img1.shape[:2]
    # img1 = img1[0: int(height / 2), 0: width]
    # img2 = img2[0: int(height / 2), 0: width]
    size = (int(width * scale), int(height * scale))

    img11 = cv2.resize(img1, size, interpolation=cv2.INTER_AREA)
    img22 = cv2.resize(img2, size, interpolation=cv2.INTER_AREA)

    # 获取关键点
    kp1, des1 = sift.detectAndCompute(img11, None)  # des是描述子
    kp2, des2 = sift.detectAndCompute(img22, None)  # des是描述子

    # BFMatcher解决匹配
    bf = cv2.BFMatcher()
    matches = bf.knnMatch(des1, des2, k=2)
    # 调整ratio
    good = []
    for m, n in matches:
        if m.distance < 0.75 * n.distance:
            good.append([m])

    img5 = cv2.drawMatchesKnn(img11, kp1, img22, kp2, good, None, flags=2)

    # 获取匹配点的坐标
    result = [
        ['DMatch', 'distance', 'x_keypoint1', 'y_keypoint1', 'response1', 'x_keypoint2', 'y_keypoint2', 'response2']]
    reid = []  # 用于判断是否重复，重复不加入输出列表，不重复才加入输出列表
    for match in range(len(good)):
        distance = good[match][0].distance
        p1 = kp1[good[match][0].queryIdx].pt
        response1 = kp1[good[match][0].queryIdx].response
        p2 = kp2[good[match][0].trainIdx].pt
        response2 = kp2[good[match][0].trainIdx].response

        if match == 0:
            result.append(
                [str(good[match][0]), distance, p1[0], p1[1], response1, p2[0], p2[1], response2])
            reid.append(tuple([p2[0], p2[1]]))

        else:
            if tuple([p2[0], p2[1]]) not in reid:
                result.append(
                    [str(good[match][0]), distance, p1[0], p1[1], response1, p2[0], p2[1], response2])
                reid.append(tuple([p2[0], p2[1]]))

    return result, img5

# 定义提取单帧图片检测结果的函数#相比于each_frame，直接在此处y=h-y
def each_frame2(result, classes, frame_id, score_th, w, h):
    result_true = [['frame_id', 'labels', 'the_id', 'xmin', 'ymin', 'xmax', 'ymax', '置信度', 'x_center', 'y_center', 'row', 'column']]

    labels = result.pred_instances.labels
    bboxes = result.pred_instances.bboxes
    scores = result.pred_instances.scores

    if len(labels) != 0:

        for j in range(len(labels)):
            score = scores[j].item()
            if score >= score_th:
                xmin = bboxes[j][0].item()
                ymin = bboxes[j][1].item()
                xmax = bboxes[j][2].item()
                ymax = bboxes[j][3].item()
                x_center = (xmin + xmax) / 2
                y_center = (ymin + ymax) / 2
                result_true.append([frame_id, index_to_class[str(labels[j].item())], 0, xmin, ymin, xmax, ymax, score, x_center, y_center, -1, -1])

    return result_true


# 定义生成end即last的列表方法

def single_retarget(img_result, loss_th):
    # ['frame_id', 'labels', 'the_id', 'xmin', 'ymin', 'xmax', 'ymax', '置信度', 'x_center', 'y_center', 'row', 'column']
    id_list = list()
    for i in range(1, len(img_result) - 1):
        if img_result[i][2] == 0:
            if i != 1:
                max_id = max(id_list) + 1
            else:
                max_id = 1
            img_result[i][2] = max_id
            id_list.append(img_result[i][2])
            label, the_id, x_center, y_center = img_result[i][1], img_result[i][2], img_result[i][8], img_result[i][9]
            for j in range(i + 1, len(img_result)):
                loss = math.sqrt((img_result[j][8] - x_center) ** 2 + (img_result[j][9] - y_center) ** 2)
                if label == img_result[j][1] and loss < loss_th:
                    img_result[j][2] = the_id
    if img_result[len(img_result) - 1][2] == 0:
        img_result[len(img_result) - 1][2] = max(id_list) + 1

    # 记录id
    labels = []
    for i in range(1, len(img_result)):
        labels.append(img_result[i][1])
    labels = list(set(labels))
    labels.sort()
    label_id = dict()
    label_id['labels'] = labels
    for label in labels:
        label_id[label] = []

    for i in range(1, len(img_result)):
        label = img_result[i][1]
        id = img_result[i][2]
        if label in label_id['labels']:
            if id not in label_id[label]:
                label_id[label].append(id)
        elif label not in label_id['labels']:
            label_id['labels'].append(label)
            label_id[label] = [id]




    return img_result, label_id

def world_coordinate_mat(img_result, mat_frame_id):
    # ['frame_id', 'labels', 'the_id', 'xmin', 'ymin', 'xmax', 'ymax', '置信度', 'x_center', 'y_center', 'row', 'column']
    end = [['frame_id', 'labels', 'the_id', 'x_world', 'y_wold', 'x_center', 'y_center', 'x_base', 'y_base', 'row', 'column']]
    mat_frame_id = np.array(mat_frame_id)
    for i in range(1, len(img_result)):
        img_xy = [img_result[i][8], img_result[i][9], 1]
        img_xy = np.array(img_xy)
        world_xy = np.dot(mat_frame_id, img_xy)
        x_world, y_world = world_xy[0], world_xy[1]
        end.append(
            [img_result[i][0], img_result[i][1], img_result[i][2], x_world, y_world, img_result[i][8], img_result[i][9], mat_frame_id[0][2], mat_frame_id[1][2], img_result[i][10], img_result[i][11]])
    return end

def upgrade_id(resultt, last_method, label_id, loss_th, last_labels_id):
    last_method_labels = []
    for i in range(1, len(last_method)):
        last_method_labels.append(last_method[i][1])
    labelses = list(set(last_method_labels))
    # print('更新前:{}'.format(resultt))
    for i in range(1, len(resultt)):
        if resultt[i][1] not in labelses:
            label_id['labels'].append(resultt[i][1])
            label_id[resultt[i][1]] = [1]
            resultt[i][2] = 1
            # print('新增新标签的id:{}'.format(resultt[i][2]))
        else:
            if resultt[i][2] == 0:
                # print('id为0需要更新:{}'.format(resultt[i]))
                losses = []
                ids = []
                for j in range(1, len(last_method)):
                    loss1 = math.sqrt(
                        (resultt[i][3] - last_method[j][3]) ** 2 + (resultt[i][4] - last_method[j][4]) ** 2)
                    if resultt[i][0] != last_method[j][0] and resultt[i][1] == last_method[j][1] and loss1 <= 250: # 对于dxdy的设定
                        losses.append(loss1)
                        ids.append(last_method[j][2])
                        # print(last_method[j])
                if len(losses) != 0:
                    resultt[i][2] = ids[losses.index(min(losses))]
                else:
                    # 说明已有标签的不同目标
                    # print(resultt[i][1])
                    # print(label_id)
                    max_id = max(label_id[resultt[i][1]])
                    label_id[resultt[i][1]].append(max_id + 1)
                    resultt[i][2] = max_id + 1
    # print('与前面所有全局坐标更新后:{}'.format(resultt))
    for i in range(1, len(resultt)):
        if resultt[i][2] == 0:
            print('------id没更新完，完了出问题了')

    return resultt

def upgrade_id1(before_result, img_result, loss_th, h, dx_b, dy_b):
    # 更新id
    # ['frame_id', 'labels', 'the_id', 'xmin', 'ymin', 'xmax', 'ymax', '置信度', 'x_center', 'y_center']
    new_old_info = []  # 'x_center_new, y_center_new, x_center_old, y_center_old,loss'
    for i in range(1, len(img_result)):
        for j in range(1, len(before_result)):
            loss = math.sqrt(
                (img_result[i][8] - before_result[j][8]) ** 2 + (img_result[i][9] - before_result[j][9]) ** 2)
            if img_result[i][1] == before_result[j][1] and loss <= loss_th:
                new_old_info.append(
                    [img_result[i][8], img_result[i][9], before_result[j][8], before_result[j][9], loss])
                break
    # detectin 共同目标，loss最小
    if len(new_old_info) == 0:
        con_target_detection = 0
    else:
        min_loss = new_old_info[0][4]
        min_loss_id = 0
        for i in range(1, len(new_old_info)):
            if new_old_info[i][4] < min_loss:
                min_loss = new_old_info[i][4]
                min_loss_id = i
        con_target_detection = new_old_info[min_loss_id]

    for i in range(1, len(img_result)):
        losses = []
        ids = []
        for j in range(1, len(before_result)):
            loss = math.sqrt(
                (img_result[i][8] - before_result[j][8]) ** 2 + (img_result[i][9] - before_result[j][9]) ** 2)
            if img_result[i][1] == before_result[j][1] and loss <= loss_th:
                losses.append(loss)
                ids.append(before_result[j][2])
        if len(losses) != 0:
            img_result[i][2] = ids[losses.index(min(losses))]

    dx_sum = 0
    dy_sum = 0
    dxs, dys = [], []
    for item in new_old_info:
        dx_sum += item[0] - item[2]
        dy_sum += item[1] - item[3]
        dxs.append(item[0] - item[2])
        dys.append(item[1] - item[3])
    # print(dx_sum,dy_sum, len(new_old_info))
    if len(new_old_info) == 0:
        dx, dy = dx_b, dy_b
    else:
        dx_max, dx_min = max(dxs), min(dxs)
        dy_max, dy_min = max(dys), min(dys)
        # print(dy_max, dy_min)
        if abs(dx_min) >= dx_max:
            dx_abs = dx_min
        else:
            dx_abs = dx_max
        if abs(dy_min) >= dy_max:
            dy_abs = dy_min
        else:
            dy_abs = dy_max
        # dx = dx_abs
        # dy = dy_abs

        dx = dx_sum/len(new_old_info)
        dy = dy_sum/len(new_old_info)
        # print(dx,dy)
    last_labels_id = []
    for i in range(1, len(before_result)):
        last_labels_id.append([before_result[i][1], before_result[i][2]])
    return img_result, last_labels_id, dx, dy, con_target_detection



# 计算此帧基点sumx,sumy
def compute_sum_dxdy_mat(con_target, mat_frame_id_before, aefa_now):
    if con_target == 0:
        print('该两帧有未检测出任何目标的,返回上一帧矩阵')
        return mat_frame_id_before
    else:
        # 'x_center_new, y_center_new, x_center_old, y_center_old,loss'
        if aefa_now >= 0:
            aefa_now = aefa_now % 360
        if aefa_now < 0:
            aefa_now = aefa_now % -360

        aefa_now = aefa_now * pi / 180
        mat_frame_id_now11 = math.cos(aefa_now)
        mat_frame_id_now12 = - math.sin(aefa_now)
        mat_frame_id_now21 = math.sin(aefa_now)
        mat_frame_id_now22 = math.cos(aefa_now)

        mat_frame_id_before = np.array(mat_frame_id_before)
        xy_before = [con_target[0], con_target[1], 1]
        xy_before = np.array(xy_before)
        world_xy_con = np.dot(mat_frame_id_before, xy_before)

        x_now = con_target[2]
        y_now = con_target[3]
        x_base_mat = world_xy_con[0] - x_now * mat_frame_id_now11 - y_now * mat_frame_id_now12
        y_base_mat = world_xy_con[1] - x_now * mat_frame_id_now21 - y_now * mat_frame_id_now22


        mat_frame_id_now = [[mat_frame_id_now11, mat_frame_id_now12, x_base_mat],
                            [mat_frame_id_now21, mat_frame_id_now22, y_base_mat],
                            [0, 0, 1]]
        return mat_frame_id_now
def compute_sum_dxdy_mat_detection(con_target, mat_frame_id_before, aefa_now):
    if con_target == 0:
        print('该两帧有未检测出任何目标的,返回上一帧矩阵')
        return mat_frame_id_before
    else:
        # 'x_center_new, y_center_new, x_center_old, y_center_old,loss'
        if aefa_now >= 0:
            aefa_now = aefa_now % 360
        if aefa_now < 0:
            aefa_now = aefa_now % -360

        aefa_now = aefa_now * pi / 180

        mat_frame_id_now11 = math.cos(aefa_now)
        mat_frame_id_now12 = - math.sin(aefa_now)
        mat_frame_id_now21 = math.sin(aefa_now)
        mat_frame_id_now22 = math.cos(aefa_now)

        mat_frame_id_before = np.array(mat_frame_id_before)
        xy_before = [con_target[2], con_target[3], 1]
        xy_before = np.array(xy_before)
        world_xy_con = np.dot(mat_frame_id_before, xy_before)

        x_now = con_target[0]
        y_now = con_target[1]
        x_base_mat = world_xy_con[0] - x_now * mat_frame_id_now11 - y_now * mat_frame_id_now12
        y_base_mat = world_xy_con[1] - x_now * mat_frame_id_now21 - y_now * mat_frame_id_now22

        mat_frame_id_now = [[mat_frame_id_now11, mat_frame_id_now12, x_base_mat],
                            [mat_frame_id_now21, mat_frame_id_now22, y_base_mat],
                            [0, 0, 1]]
        return mat_frame_id_now
def compute_sum_dxdy_mat_dxdy(mat_frame_id_before, aefa_now, dx, dy):

    # 'x_center_new, y_center_new, x_center_old, y_center_old,loss'
    if aefa_now >= 0:
        aefa_now = aefa_now % 360
    if aefa_now < 0:
        aefa_now = aefa_now % -360

    aefa_now = aefa_now * pi / 180
    mat_frame_id_now11 = math.cos(aefa_now)
    mat_frame_id_now12 = - math.sin(aefa_now)
    mat_frame_id_now21 = math.sin(aefa_now)
    mat_frame_id_now22 = math.cos(aefa_now)

    x_base_before, y_base_before = mat_frame_id_before[0][2], mat_frame_id_before[1][2]

    x_base_now, y_base_now = x_base_before - dx, y_base_before - dy

    mat_frame_id_now = [[mat_frame_id_now11, mat_frame_id_now12, x_base_now],
                        [mat_frame_id_now21, mat_frame_id_now22, y_base_now],
                        [0, 0, 1]]
    return mat_frame_id_now
def compute_sum_dxdy_origin(sum_dx_before, sum_dy_before, dsumx_b, dsumy_b, dxdy_list):
    if len(dxdy_list) < 1:
        print('该两帧有未检测出任何目标的,不能计算增量,返回上一帧的增量')
        return sum_dx_before + dsumx_b, sum_dy_before + dsumy_b, dsumx_b, dsumy_b
    else:
        dx_dy = []
        for item in dxdy_list:
            dx_dy.append([item[0] - item[2], item[1] - item[3]])
        dx = (sum(i[0] for i in dx_dy)) / len(dx_dy)
        dy = (sum(i[1] for i in dx_dy)) / len(dx_dy)

        return sum_dx_before + dx, sum_dy_before + dy, dx, dy

def pred_single_frame(result_id, img_path, text_size):
    # ['frame_id', 'labels', 'the_id', 'xmin', 'ymin', 'xmax', 'ymax', '置信度', 'x_center', 'y_center', 'row', 'column']
    im = mmcv.imread(img_path, channel_order='rgb')
    labels = []
    for i in range(1, len(result_id)):
        labels.append(result_id[i][1])
    my_dict = {}
    for word in labels:
        if word in my_dict:
            my_dict[word] += 1
        else:
            my_dict[word] = 1

    my_list = list(my_dict.items())
    my_list.append(('total', len(result_id) - 1))

    font = cv2.FONT_HERSHEY_SIMPLEX
    for i in range(len(my_list)):
        text = '{}'.format(my_list[i][0]) + ":" + '{}'.format(my_list[i][1])
        cv2.putText(im, text, (5, 2 + (text_size + 10) * (i + 1)), font, 1, (0, 0, 255), 2, cv2.LINE_AA)


    # 增加id ['frame_id', 'labels', 'the_id', 'xmin', 'ymin', 'xmax', 'ymax', '置信度', 'x_center', 'y_center']
    for i in range(1, len(result_id)):
        rr, gg, bb = palette[class_to_palette[result_id[i][1]]][0], palette[class_to_palette[result_id[i][1]]][1], palette[class_to_palette[result_id[i][1]]][2],
        text_id = str(result_id[i][2])
        cv2.putText(im, text_id, (int(result_id[i][3]), int(result_id[i][4])), font, 1, (bb, gg, rr), 2, cv2.LINE_AA)
    return im
def compute_row_column(index_r, rc_th):
    index_value = []
    for i in range(len(index_r)):
        if i == 0:
            index_value.append([index_r[i][0], index_r[i][1] - index_r[i][1]])
        else:
            index_value.append([index_r[i][0], index_r[i][1] - index_r[i-1][1]])
    index_rs = []
    nums = 0
    for i in range(len(index_value)):
        if index_value[i][1] <= rc_th:
            index_rs.append([index_value[i][0], nums])
        else:
            nums += 1
            index_rs.append([index_value[i][0], nums])
    return index_rs

# 新的降重函数：将阈值内的点取平均值
def find_the_same_obj(move_center, each_class, loss_th):
    decrease_data = move_center
    index = []
    for i in range(1, len(move_center)):
        for j in range(len(each_class)):
            if move_center[i][0] == each_class[j][0] and math.sqrt((each_class[j][2] - move_center[i][2]) ** 2 + (
                    each_class[j][3] - move_center[i][3]) ** 2) <= loss_th:
                each_class.append(move_center[i])
                index.append(i)
                break
    new_data = list()
    # 找到不属于这一类目标
    for i in range(len(decrease_data)):
        t = 0
        for j in index:
            if i == j:
                break
            else:
                t += 1
        if t == len(index):
            new_data.append(decrease_data[i])  # 将不属于这一类的目标增加到新数组，相当于减去这一类的
    return new_data, each_class, len(index)


def each_class_avarage(each_class):
    info_xy = []
    world_x = 0
    world_y = 0
    frame_id = each_class[0][0]
    labels = each_class[0][1]
    the_id = each_class[0][2]
    for row in each_class:
        world_x += row[3]
        world_y += row[4]
        info_xy.append([row[3], row[4]])
    world_x = world_x / len(each_class)
    world_y = world_y / len(each_class)
    return [frame_id, labels, the_id, world_x, world_y], [world_x, world_y]



def check(values, num):
    t = 0
    for i in range(len(values)):

        if values[i] > num:
            t += 1

    if t == len(values):
        return True
    else:
        return False


# 统计目标个数,demo函数的
def statistic_messeges(str_list):
    str_dict = {'total': len(str_list)}
    for s in str_list:
        if s not in str_dict:
            str_dict[s] = 1
        else:
            str_dict[s] += 1
    json_dict = str_dict
    list_dict = list(str_dict.items())
    list_dict = [str(i).replace("'", "").replace(",", ":").replace("(", "").replace(")", "") for i in list_dict]
    return list_dict, json_dict


# 绘入CAD相关函数
# 坐标点转化为浮点数
def vtpnt(x, y, z=0):
    return win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, (x, y, z))

# 列表转化为浮点数
def vtfloat(lst):
    return win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, lst)

def get_angle_four1(x1, y1, x2, y2):
    dx = x2 - x1
    dy = y2 - y1
    angle_radians = math.atan2(dy, dx)
    angle_degrees = (math.degrees(angle_radians) + 360) % 360
    return angle_degrees
def getline_points_row(num, circle_data):
    row_point_down = []
    for i in num:
        row = []
        for j in circle_data:
            if i == j[1]:
                row.append([j[0], j[1], j[2], j[3], j[4]])
        row.sort(key=lambda x: x[2])  # 排序
        row_point_down.append(row)
    return row_point_down
def getline_points_column(num, circle_data):
    row_point_down = []
    for i in num:
        row = []
        for j in circle_data:
            if i == j[2]:
                row.append([j[0], j[1], j[2], j[3], j[4]])
        row.sort(key=lambda x: x[1])  # 排序
        row_point_down.append(row)
    return row_point_down
def getpoints_fugan1(circle_xy_down, circle_xy_up):
    # ['labels','row','column','x_world','y_world', 'down or up', 'row,colum']
    five_points = []
    for item in circle_xy_down:
        point = []
        point.append([item[3], item[4], 0])

        for i in range(len(circle_xy_up)):
            if (item[1] == circle_xy_up[i][1] and item[2] == circle_xy_up[i][2]) or (item[1] == circle_xy_up[i][1] and item[2] == circle_xy_up[i][2] - 1) or (
                    item[1] == circle_xy_up[i][1] - 1 and item[2] == circle_xy_up[i][2] - 1) or (item[1] == circle_xy_up[i][1] - 1 and item[2] == circle_xy_up[i][2]):
                point.append([circle_xy_up[i][3], circle_xy_up[i][4], 0])
            if len(point) == 5:
                point = [num for sublist in point for num in sublist]
                break
            elif len(point) < 5 and i == len(circle_xy_up) - 1:
                print('未检测出{}行{}列的下弦节点周围的4个上弦节点'.format(item[1], item[2]))
                point = [num for sublist in point for num in sublist]
        five_points.append(point)

    return five_points
def draw_labels(max_x, r_labels, labels_list, index_to_color, msp, layername, clr):
    for i in range(len(labels_list)):
        circle_center = vtpnt(max_x + distance_down_x / 2 + r_labels / 2, 4 * r_labels * (i + 1), 0)
        color = index_to_color[labels_list[i]]
        circleObj = msp.AddCircle(circle_center, r_labels)
        circleObj.Layer = layername[5]
        clr.SetRGB(color[0], color[1], color[2])
        circleObj.TrueColor = clr
        text = msp.AddText('%s' % labels_list[i],
                           vtpnt(max_x + distance_down_x / 2 + r_labels * 2.5, 4 * r_labels * (i + 1) - r_labels / 2,
                                 0), r_labels)
        text.Layer = layername[5]
        clr.SetRGB(255, 255, 255)
        text.TrueColor = clr
def drawpline_row(point, msp, clr, cr_value, layername, r):
    for i in point:
        for j in range(len(i) - 1):
            pline_point = []
            pline_point.append([i[j][3] + r, i[j][4], 0, i[j + 1][3] - r, i[j + 1][4], 0])
            pline_point = [i for j in pline_point for i in j]
            pline_point = vtfloat(pline_point)
            plineObj = msp.AddPolyline(pline_point)
            clr.SetRGB(cr_value[0], cr_value[1], cr_value[2])
            plineObj.TrueColor = clr
            plineObj.Layer = layername
def drawpline_column(point, msp, clr, cr_value, layername, r):
    for i in point:
        for j in range(len(i) - 1):
            pline_point = []

            pline_point.append([i[j][3], i[j][4] + r, 0, i[j + 1][3], i[j + 1][4] - r, 0])
            pline_point = [i for j in pline_point for i in j]
            pline_point = vtfloat(pline_point)
            plineObj = msp.AddPolyline(pline_point)
            clr.SetRGB(cr_value[0], cr_value[1], cr_value[2])
            plineObj.TrueColor = clr
            plineObj.Layer = layername
def dealwithpoints1(data_value):
    angle_four = []
    x1, y1 = data_value[0], data_value[1]
    for i in range(int((len(data_value)-3)/3)):
        x2, y2 = data_value[(i + 1) * 3], data_value[(i + 1) * 3 + 1]
        angle_four.append(get_angle_four1(x1, y1, x2, y2))
    # 将顺序变为逆时针,与坐标增减对应
    data_value_new = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    angle_four_new = [0, 0, 0, 0]
    data_value_new[0], data_value_new[1], data_value_new[2] = data_value[0], data_value[1], data_value[2]
    for i in range(len(angle_four)):
        if 180 < angle_four[i] < 270:
            data_value_new[3], data_value_new[4], data_value_new[5] = data_value[3 * (i + 1)], data_value[
                3 * (i + 1) + 1], data_value[3 * (i + 1) + 2]
            angle_four_new[0] = angle_four[i]
        elif 270 < angle_four[i] < 360:
            data_value_new[6], data_value_new[7], data_value_new[8] = data_value[3 * (i + 1)], data_value[
                3 * (i + 1) + 1], data_value[3 * (i + 1) + 2]
            angle_four_new[1] = angle_four[i]
        elif 0 < angle_four[i] < 90:
            data_value_new[9], data_value_new[10], data_value_new[11] = data_value[3 * (i + 1)], data_value[
                3 * (i + 1) + 1], data_value[3 * (i + 1) + 2]
            angle_four_new[2] = angle_four[i]
        elif 90 < angle_four[i] < 180:
            data_value_new[12], data_value_new[13], data_value_new[14] = data_value[3 * (i + 1)], data_value[
                3 * (i + 1) + 1], data_value[3 * (i + 1) + 2]
            angle_four_new[3] = angle_four[i]
    # 转换为弧度
    for i in range(4):
        angle_four_new[i] = angle_four_new[i] * pi / 180
    return data_value_new, angle_four_new
def draw_fugan1(item, msp, clr, layername, angle_four, cr_value, r):
    for i in range(4):
        pline_point = []
        if i == 0:
            if angle_four[0] != 0:
                pline_point.append(
                    [item[0] + r * math.sin(angle_four[0]), item[1] + r * math.cos(angle_four[0]), item[2],
                     item[(i + 1) * 3] - r * math.sin(angle_four[0]),
                     item[(i + 1) * 3 + 1] - r * math.cos(angle_four[0]), item[(i + 1) * 3 + 2]])
                pline_point = [i for j in pline_point for i in j]
                pline_point = vtfloat(pline_point)
                plineObj = msp.AddPolyline(pline_point)
                clr.SetRGB(cr_value[0], cr_value[1], cr_value[2])
                plineObj.TrueColor = clr
                plineObj.Layer = layername
        elif i == 1:
            if angle_four[1] != 0:
                pline_point.append(
                    [item[0] + r * math.cos(angle_four[1]), item[1] + r * math.sin(angle_four[1]), item[2],
                     item[(i + 1) * 3] - r * math.cos(angle_four[1]),
                     item[(i + 1) * 3 + 1] - r * math.sin(angle_four[1]), item[(i + 1) * 3 + 2]])
                pline_point = [i for j in pline_point for i in j]
                pline_point = vtfloat(pline_point)
                plineObj = msp.AddPolyline(pline_point)
                clr.SetRGB(cr_value[0], cr_value[1], cr_value[2])
                plineObj.TrueColor = clr
                plineObj.Layer = layername
        elif i == 2:
            if angle_four[2] != 0:
                pline_point.append(
                    [item[0] + r * math.cos(angle_four[2]), item[1] + r * math.sin(angle_four[2]), item[2],
                     item[(i + 1) * 3] - r * math.cos(angle_four[2]),
                     item[(i + 1) * 3 + 1] - r * math.sin(angle_four[2]), item[(i + 1) * 3 + 2]])
                pline_point = [i for j in pline_point for i in j]
                pline_point = vtfloat(pline_point)
                plineObj = msp.AddPolyline(pline_point)
                clr.SetRGB(cr_value[0], cr_value[1], cr_value[2])
                plineObj.TrueColor = clr
                plineObj.Layer = layername
        else:
            if angle_four[3] != 0:
                pline_point.append(
                    [item[0] + r * math.cos(angle_four[3]), item[1] + r * math.sin(angle_four[3]), item[2],
                     item[(i + 1) * 3] - r * math.cos(angle_four[3]),
                     item[(i + 1) * 3 + 1] - r * math.sin(angle_four[3]), item[(i + 1) * 3 + 2]])
                pline_point = [i for j in pline_point for i in j]
                pline_point = vtfloat(pline_point)
                plineObj = msp.AddPolyline(pline_point)
                clr.SetRGB(cr_value[0], cr_value[1], cr_value[2])
                plineObj.TrueColor = clr
                plineObj.Layer = layername

def draw_fugan(item, msp, clr, layername, angle_four, cr_value, r):
    for i in range(4):
        pline_point = []
        if i == 0:
            pline_point.append(
                [item[0] - r * math.sin(angle_four[0]), item[1] - r * math.cos(angle_four[0]), item[2],
                 item[(i + 1) * 3] + r * math.sin(angle_four[0]),
                 item[(i + 1) * 3 + 1] + r * math.cos(angle_four[0]), item[(i + 1) * 3 + 2]])
        elif i == 1:
            pline_point.append(
                [item[0] + r * math.cos(angle_four[1]), item[1] - r * math.sin(angle_four[1]), item[2],
                 item[(i + 1) * 3] - r * math.cos(angle_four[1]),
                 item[(i + 1) * 3 + 1] + r * math.sin(angle_four[1]), item[(i + 1) * 3 + 2]])
        elif i == 2:
            pline_point.append(
                [item[0] + r * math.sin(angle_four[2]), item[1] + r * math.cos(angle_four[2]), item[2],
                 item[(i + 1) * 3] - r * math.sin(angle_four[2]),
                 item[(i + 1) * 3 + 1] - r * math.cos(angle_four[2]), item[(i + 1) * 3 + 2]])
        else:
            pline_point.append(
                [item[0] - r * math.cos(angle_four[3]), item[1] + r * math.sin(angle_four[3]), item[2],
                 item[(i + 1) * 3] + r * math.cos(angle_four[3]),
                 item[(i + 1) * 3 + 1] - r * math.sin(angle_four[3]), item[(i + 1) * 3 + 2]])
        pline_point = [i for j in pline_point for i in j]
        pline_point = vtfloat(pline_point)
        plineObj = msp.AddPolyline(pline_point)
        clr.SetRGB(cr_value[0], cr_value[1], cr_value[2])
        plineObj.TrueColor = clr
        plineObj.Layer = layername
def find_value(lt):
    lt = list(set(lt))
    lt.sort()
    for i in range(len(lt)):
        if i != lt[i]:
            return lt[i]
        elif i == len(lt) - 1:
            return 0
def getpoints_fugan(circle_xy_down, circle_xy_up):
    five_points = []
    for item in circle_xy_down:
        point = []
        point.append([item[3], item[4], 0])
        for i in circle_xy_up:
            if (item[1] == i[1] and item[2] == i[2]) or (item[1] == i[1] and item[2] == i[2] - 1) or (
                    item[1] == i[1] - 1 and item[2] == i[2] - 1) or (item[1] == i[1] - 1 and item[2] == i[2]):
                point.append([i[3], i[4], 0])
                if len(point) == 5:
                    point = [num for sublist in point for num in sublist]
                    break
        five_points.append(point)
    return five_points
def get_angle_four(x1, y1, x2, y2):
    dx = x2 - x1
    dy = y2 - y1
    rads = math.atan2(-dy, dx)
    rads %= 2 * math.pi
    return math.degrees(rads)
def dealwithpoints(data_value, pi):
    angle_four = []
    x1, y1 = data_value[0], data_value[1]
    for i in range(4):
        x2, y2 = data_value[(i + 1) * 3], data_value[(i + 1) * 3 + 1]
        if i == 0:
            angle_four.append(get_angle_four(x1, y1, x2, y2))
        elif i == 1:
            angle_four.append(get_angle_four(x1, y1, x2, y2))
        elif i == 2:
            angle_four.append(get_angle_four(x1, y1, x2, y2))
        else:
            angle_four.append(get_angle_four(x1, y1, x2, y2))
    # 将顺序变为逆时针,与坐标增减对应
    data_value_new = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    angle_four_new = [0, 0, 0, 0]
    data_value_new[0], data_value_new[1], data_value_new[2] = data_value[0], data_value[1], data_value[2]
    for i in range(4):
        if 90 < angle_four[i] < 180:
            data_value_new[3], data_value_new[4], data_value_new[5] = data_value[3 * (i + 1)], data_value[
                3 * (i + 1) + 1], data_value[3 * (i + 1) + 2]
            angle_four_new[0] = angle_four[i]
        elif 0 < angle_four[i] < 90:
            data_value_new[6], data_value_new[7], data_value_new[8] = data_value[3 * (i + 1)], data_value[
                3 * (i + 1) + 1], data_value[3 * (i + 1) + 2]
            angle_four_new[1] = angle_four[i]
        elif 270 < angle_four[i] < 360:
            data_value_new[9], data_value_new[10], data_value_new[11] = data_value[3 * (i + 1)], data_value[
                3 * (i + 1) + 1], data_value[3 * (i + 1) + 2]
            angle_four_new[2] = angle_four[i]
        elif 180 < angle_four[i] < 270:
            data_value_new[12], data_value_new[13], data_value_new[14] = data_value[3 * (i + 1)], data_value[
                3 * (i + 1) + 1], data_value[3 * (i + 1) + 2]
            angle_four_new[3] = angle_four[i]
    # 转换为弧度
    angle_four_new[0], angle_four_new[1], angle_four_new[2], angle_four_new[3] = angle_four_new[0] * pi / 180 - pi / 2, \
                                                                                 angle_four_new[1] * pi / 180, \
                                                                                 angle_four_new[
                                                                                     2] * pi / 180 - 3 * pi / 2, \
                                                                                 angle_four_new[3] * pi / 180 - pi
    return data_value_new, angle_four_new
def draw_labels1(max_x, r_labels, labels_list, index_to_color, msp, layername, clr, distance_down_x):
    for i in range(len(labels_list)):
        circle_center = vtpnt(max_x + distance_down_x / 2 + r_labels / 2, 4 * r_labels * (i + 1), 0)
        color = index_to_color[labels_list[i]]
        circleObj = msp.AddCircle(circle_center, r_labels)
        circleObj.Layer = layername[5]
        clr.SetRGB(color[0], color[1], color[2])
        circleObj.TrueColor = clr
        text = msp.AddText('%s' % labels_list[i],
                           vtpnt(max_x + distance_down_x / 2 + r_labels * 2.5, 4 * r_labels * (i + 1) - r_labels / 2,
                                 0), r_labels)
        text.Layer = layername[5]
        clr.SetRGB(255, 255, 255)
        text.TrueColor = clr

# 训练时将下载的网络模型文件保存到
os.environ['TORCH_HOME'] = '../'
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
print(device)

video_path, backbone_model, checkpoint, combine_videopath = None, None, None, None
fig = None
pgb_total = 1
frame_id = 0
width = 655  # 用于可视化的
height = 505


class TrainThread(QThread):
    change_value = pyqtSignal(int)

    def get_args(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c
        # self.epochs = epochs
        # self.img_scale = img_scale
        # self.batch_size = batch_size
        # self.data_root = data_root

    def run(self):
        # your code
        args_train = train_parser()
        # 获取用户设置的参数
        args_train.config = self.a
        args_train.work_dir = self.b
        # args_train.epochs = self.epochs
        # args_train.img_scale = self.img_scale
        # args_train.batch_size = self.batch_size
        # args_train.data_root = self.data_root
        args_train.load_from = self.c if self.c != '' else None
        train_main(args=args_train)
        self.change_value.emit(1)

# 可视化绘入CAD
class DrawtoCAD(QThread):
    change_value = pyqtSignal(int, int, str)

    def get_args(self, points_r, labels):
        self.points_r = points_r
        self.labels = labels

    def run(self):
        r = self.points_r
        labels = self.labels

        # 对CAD的操作
        acad = win32com.client.Dispatch("AutoCAD.Application")
        # 显示AutoCAD界面
        doc = acad.ActiveDocument
        msp = doc.ModelSpace
        version = acad.Application.Version[:2]  # 当前CAD的版本号
        clr = acad.Application.GetInterfaceObject("AutoCAD.AcCmColor.%s" % version)

        self.change_value.emit(100, 0, '数据处理')
        # 新建图层
        layername = ['下弦杆节点', '上弦杆节点', '下弦杆', '上弦杆', '腹杆', '标签']  # 下弦杆节点，上弦杆节点，下弦杆，上弦杆，腹杆
        for item in layername:
            doc.Layers.Add(item)


        labels_list = ['down', 'up']
        row_list = np.unique(df_dxf['row'])
        column_list = np.unique(df_dxf['column'])
        classes_list = [row_list, column_list]
        classes_list = [x for l in classes_list for x in l]
        classes_list = list(set(classes_list))
        palette = sns.hls_palette(len(classes_list), l=0.1, h=0.9)  # 配色方案,默认0.3，变化幅度#亮度，色相
        # palette = sns.cubehelix_palette(len(classes_list), start=255, light=0.9, rot=-1.5)
        np.random.shuffle(palette)
        index_to_color = {classes_list[i]: [255 * palette[i][0], 255 * palette[i][1], 255 * palette[i][2]] for i in
                          range(len(classes_list))}
        index_to_color_labels = {'down': [0, 255, 255], 'up': [255, 0, 255]}
        max_x = max(map(lambda x: x[3], circle_all))

        # 杆件颜色
        cr_value = [[0, 0, 255], [0, 255, 0], [255, 0, 0]]  # 上弦杆，腹杆，下弦杆
        row_num_down = np.unique(df_down['row'])
        column_num_down = np.unique(df_down['column'])
        row_num_up = np.unique(df_up['row'])
        column_num_up = np.unique(df_up['column'])
        # 获得下弦杆行和列点
        row_point_down = getline_points_row(row_num_down, circle_xy_down)
        column_point_down = getline_points_column(column_num_down, circle_xy_down)
        # 获得上弦杆行和列点
        row_point_up = getline_points_row(row_num_up, circle_xy_up)
        column_point_up = getline_points_column(column_num_up, circle_xy_up)

        # 获得每个下弦杆节点周围四个上弦杆节点
        points_fugan = getpoints_fugan(circle_xy_down, circle_xy_up)

        num_points = len(circle_all)
        num_row_down = sum([(len(i) - 1) for i in row_point_down])
        num_column_down = sum([(len(i) - 1) for i in column_point_down])
        num_row_up = sum([(len(i) - 1) for i in row_point_up])
        num_column_up = sum([(len(i) - 1) for i in column_point_up])

        num_fugan = len(points_fugan) * 4

        total = num_points + num_row_down + num_column_down + num_row_up + num_column_up + num_fugan

        self.change_value.emit(100, 0, '绘制节点')
        # 绘制节点坐标，以圆表示
        r = float(r)
        for item in circle_all:
            center = vtpnt(item[3], item[4], 0)
            if labels == 'labels':
                color = index_to_color_labels[item[0]]
            elif labels == 'row':
                color = index_to_color[item[1]]
            else:
                color = index_to_color[item[2]]

            circleObj = msp.AddCircle(center, r)
            clr.SetRGB(color[0], color[1], color[2])
            circleObj.TrueColor = clr
            circleObj.Layer = layername[0] if item[0] == 'down' else layername[1]
        the_num = num_points
        self.change_value.emit(total, the_num, '绘制下弦杆')

        # 绘制标签

        if labels == 'labels':
            draw_labels(max_x=max_x, r_labels=r, labels_list=labels_list, index_to_color=index_to_color_labels, msp=msp,
                        layername=layername, clr=clr)
        elif labels == 'row':
            draw_labels(max_x=max_x, r_labels=r, labels_list=row_list, index_to_color=index_to_color, msp=msp,
                        layername=layername, clr=clr)
        else:
            draw_labels(max_x=max_x, r_labels=r, labels_list=column_list, index_to_color=index_to_color, msp=msp,
                        layername=layername, clr=clr)

        # 绘制上下弦杆、腹杆

        # 绘上下弦杆
        drawpline_row(row_point_down, msp, clr, cr_value[2], layername[2], r)
        the_num += num_row_down
        self.change_value.emit(total, the_num, '绘制下弦杆')
        drawpline_column(column_point_down, msp, clr, cr_value[2], layername[2], r)
        the_num += num_column_down
        self.change_value.emit(total, the_num, '绘制上弦杆')
        drawpline_row(row_point_up, msp, clr, cr_value[0], layername[3], r)
        the_num += num_column_up
        self.change_value.emit(total, the_num, '绘制上弦杆')
        drawpline_column(column_point_up, msp, clr, cr_value[0], layername[3], r)
        the_num += num_column_up
        self.change_value.emit(total, the_num, '绘制腹杆')

        # 绘制腹杆
        for data_value in points_fugan:
            # 计算角度,并将数据转化为左下逆时针:左下开始，右下，右上，左上
            point5_five, angle_four = dealwithpoints(data_value, pi)
            # 绘制腹杆
            draw_fugan(item=point5_five, msp=msp, clr=clr, layername=layername[4], angle_four=angle_four,
                       cr_value=cr_value[1], r=r)

        doc.Application.ZoomAll()  # 将图最适合展示
        doc.Application.Update()

        the_num = total
        self.change_value.emit(total, the_num, '绘制完成')

# 检测结果绘入CAD
class Detect_drawtocad(QThread):
    change_value = pyqtSignal(int, int, str)
    def get_args(self, points_r, labels, data_all, first_rc, save_path):
        self.points_r = points_r
        self.labels = labels
        self.data_all = data_all # ['frame_id', 'labels', 'the_id', 'x_world', 'y_world', 'correlation', 'base_x', 'base_y', 'row', 'column']
        self.first_rc = first_rc
        self.save_path = save_path
    def run(self):
        r = self.points_r
        labels = self.labels
        data_all = self.data_all

        del data_all[-1]
        self.change_value.emit(100, 0, '数据处理')

        data_all_rowcolumn = []
        for i in range(1, len(data_all)):
            data_all_rowcolumn.append([data_all[i][1], data_all[i][2], data_all[i][3], data_all[i][4], (data_all[i][8], data_all[i][9])])
        df_a = pd.DataFrame()
        df_a['labels'] = [data_all_rowcolumn[i][0] for i in range(len(data_all_rowcolumn))]
        df_a['the_id'] = [data_all_rowcolumn[i][1] for i in range(len(data_all_rowcolumn))]
        df_a['x_world'] = [data_all_rowcolumn[i][2] for i in range(len(data_all_rowcolumn))]
        df_a['y_world'] = [data_all_rowcolumn[i][3] for i in range(len(data_all_rowcolumn))]
        df_a['row-column'] = [data_all_rowcolumn[i][4] for i in range(len(data_all_rowcolumn))]
        show_feature = 'labels'
        # 二维交互式可视化plotly
        fig = px.scatter(df_a,
                         x='x_world',
                         y='y_world',
                         color=show_feature,
                         labels=show_feature,
                         symbol=show_feature,
                         hover_name='row-column',
                         opacity=0.8,
                         width=width,
                         height=height
                         )
        # 设置排版
        fig.update_layout(margin=dict(l=0, r=0, b=0, t=0))
        html_cad_path = self.save_path + '/' + 'plotly__data_after_all.html'
        fig.write_html(html_cad_path)


        print('------总节点数：{}'.format(len(data_all)-1))
        circle_xy_up = []
        circle_xy_down = []
        # 将检测结果转为上下节点两个列表['labels','row','column','x_world','y_world', 'down or up', 'row,colum', 'the_id']
        if self.first_rc == '上弦节点':
            for i in range(1, len(data_all)):
                if data_all[i][8] % 2 == 0 and data_all[i][9] % 2 == 0:
                    circle_xy_up.append(
                        [data_all[i][1], int(data_all[i][8] / 2), int(data_all[i][9] / 2), data_all[i][3],
                         data_all[i][4], 'up', (int(data_all[i][8] / 2), int(data_all[i][9] / 2)), data_all[i][2]])
                else:
                    circle_xy_down.append(
                        [data_all[i][1], int((data_all[i][8] - 1) / 2), int((data_all[i][9] - 1) / 2), data_all[i][3],
                         data_all[i][4], 'down', (int((data_all[i][8] - 1) / 2), int((data_all[i][9] - 1) / 2)), data_all[i][2]])
        else:
            for i in range(1, len(data_all)):
                if data_all[i][8] % 2 == 0 and data_all[i][9] % 2 == 0:
                    circle_xy_down.append(
                        [data_all[i][1], int(data_all[i][8] / 2), int(data_all[i][9] / 2), data_all[i][3],
                         data_all[i][4], 'up', (int(data_all[i][8] / 2), int(data_all[i][9] / 2)), data_all[i][2]])
                else:
                    circle_xy_up.append(
                        [data_all[i][1], int((data_all[i][8] - 1) / 2), int((data_all[i][9] - 1) / 2), data_all[i][3],
                         data_all[i][4], 'down', (int((data_all[i][8] - 1) / 2), int((data_all[i][9] - 1) / 2)), data_all[i][2]])
        if len(circle_xy_up) == 0:
            print('上弦节点没有，可能没检测出上节点')
        if len(circle_xy_down) == 0:
            print('下弦节点没有，可能没检测出下节点')
        print('------上弦节点数：{}'.format(len(circle_xy_up)))
        print('------下弦节点数：{}'.format(len(circle_xy_down)))

        distances_down_x1 = 0
        distances_down_x2 = 1000
        for i in range(len(circle_xy_down)):
            if circle_xy_down[i][1] == 0 and circle_xy_down[i][2] == 0:
                distances_down_x1 = circle_xy_down[i][3]
            if circle_xy_down[i][1] == 0 and circle_xy_down[i][2] == 1:
                distances_down_x2 = circle_xy_down[i][3]
                if distances_down_x1 != 0:
                    break
        distances_down_dx = distances_down_x2 - distances_down_x1

        df_down = pd.DataFrame()
        df_down['labels'] = [circle_xy_down[i][0] for i in range(0, len(circle_xy_down))]
        df_down['row'] = [circle_xy_down[i][1] for i in range(0, len(circle_xy_down))]
        df_down['column'] = [circle_xy_down[i][2] for i in range(0, len(circle_xy_down))]
        df_down['x_world'] = [circle_xy_down[i][3] for i in range(0, len(circle_xy_down))]
        df_down['y_world'] = [circle_xy_down[i][4] for i in range(0, len(circle_xy_down))]
        df_down['down'] = [circle_xy_down[i][5] for i in range(0, len(circle_xy_down))]
        df_down['row-column'] = [circle_xy_down[i][6] for i in range(0, len(circle_xy_down))]
        df_down['the_id'] = [circle_xy_down[i][7] for i in range(0, len(circle_xy_down))]

        df_up = pd.DataFrame()
        df_up['labels'] = [circle_xy_up[i][0] for i in range(0, len(circle_xy_up))]
        df_up['row'] = [circle_xy_up[i][1] for i in range(0, len(circle_xy_up))]
        df_up['column'] = [circle_xy_up[i][2] for i in range(0, len(circle_xy_up))]
        df_up['x_world'] = [circle_xy_up[i][3] for i in range(0, len(circle_xy_up))]
        df_up['y_world'] = [circle_xy_up[i][4] for i in range(0, len(circle_xy_up))]
        df_up['up'] = [circle_xy_up[i][5] for i in range(0, len(circle_xy_up))]
        df_up['row-column'] = [circle_xy_up[i][6] for i in range(0, len(circle_xy_up))]
        df_up['the_id'] = [circle_xy_up[i][7] for i in range(0, len(circle_xy_up))]

        circle_all = []
        for i in range(len(circle_xy_up)):
            circle_all.append(circle_xy_up[i])
        for i in range(len(circle_xy_down)):
            circle_all.append(circle_xy_down[i])

        df_all = pd.DataFrame()
        df_all['labels'] = [circle_all[i][0] for i in range(0, len(circle_all))]
        df_all['row'] = [circle_all[i][1] for i in range(0, len(circle_all))]
        df_all['column'] = [circle_all[i][2] for i in range(0, len(circle_all))]
        df_all['x_world'] = [circle_all[i][3] for i in range(0, len(circle_all))]
        df_all['y_world'] = [circle_all[i][4] for i in range(0, len(circle_all))]
        df_all['updown'] = [circle_all[i][5] for i in range(0, len(circle_all))]
        df_all['row-column'] = [circle_all[i][6] for i in range(0, len(circle_all))]
        df_all['the_id'] = [circle_all[i][7] for i in range(0, len(circle_all))]

        show_feature = 'updown'
        # 二维交互式可视化plotly
        fig = px.scatter(df_all,
                         x='x_world',
                         y='y_world',
                         color=show_feature,
                         labels=show_feature,
                         symbol=show_feature,
                         hover_name='row-column',
                         opacity=0.8,
                         width=width,
                         height=height
                         )
        # 设置排版
        fig.update_layout(margin=dict(l=0, r=0, b=0, t=0))
        html_cad_path = self.save_path + '/' + 'plotly_to_cad_data.html'
        fig.write_html(html_cad_path)

        show_feature1 = 'updown'
        fig = px.scatter(df_all,
                         x='x_world',
                         y='y_world',
                         color=show_feature1,
                         labels=show_feature1,
                         symbol=show_feature1,
                         hover_name='the_id',
                         opacity=0.8,
                         width=width,
                         height=height
                         )
        fig.update_layout(margin=dict(l=0, r=0, b=0, t=0))
        html_cad_path = self.save_path + '/' + 'plotly_to_cad_data1.html'
        fig.write_html(html_cad_path)

        df_all.to_csv(self.save_path + '/' + 'plotly_to_cad_data.csv')

        # 对CAD的操作
        acad = win32com.client.Dispatch("AutoCAD.Application")
        # 显示AutoCAD界面
        doc = acad.ActiveDocument
        msp = doc.ModelSpace
        version = acad.Application.Version[:2]  # 当前CAD的版本号
        clr = acad.Application.GetInterfaceObject("AutoCAD.AcCmColor.%s" % version)

        # 新建图层
        layername = ['下弦杆节点', '上弦杆节点', '下弦杆', '上弦杆', '腹杆', '标签']  # 下弦杆节点，上弦杆节点，下弦杆，上弦杆，腹杆
        for item in layername:
            doc.Layers.Add(item)

        labels_list = ['down', 'up']
        row_list = np.unique(df_all['row'])
        column_list = np.unique(df_all['column'])
        classes_list = [row_list, column_list]
        classes_list = [x for l in classes_list for x in l]
        classes_list = list(set(classes_list))
        palette = sns.hls_palette(len(classes_list), l=0.1, h=0.9)  # 配色方案,默认0.3，变化幅度#亮度，色相
        np.random.shuffle(palette)
        index_to_color = {classes_list[i]: [255 * palette[i][0], 255 * palette[i][1], 255 * palette[i][2]] for i in
                          range(len(classes_list))}
        index_to_color_labels = {'down': [0, 255, 255], 'up': [255, 0, 255]}

        max_x = max(map(lambda x: x[3], circle_all))

        # 杆件颜色
        cr_value = [[0, 0, 255], [0, 255, 0], [255, 0, 0]]  # 上弦杆，腹杆，下弦杆
        row_num_down = np.unique(df_down['row'])  # 下弦杆行号
        column_num_down = np.unique(df_down['column'])
        row_num_up = np.unique(df_up['row'])
        column_num_up = np.unique(df_up['column'])
        # 获得下弦杆行和列点
        row_point_down = getline_points_row(row_num_down, circle_xy_down)
        column_point_down = getline_points_column(column_num_down, circle_xy_down)
        # 获得上弦杆行和列点
        row_point_up = getline_points_row(row_num_up, circle_xy_up)
        column_point_up = getline_points_column(column_num_up, circle_xy_up)

        # 获得每个下弦杆节点周围上弦杆节点
        points_fugan = getpoints_fugan1(circle_xy_down, circle_xy_up)  # 针对上弦杆为支座的，对于下弦杆为支座情况未考虑

        num_points = len(circle_all)
        num_row_down = sum([(len(i) - 1) for i in row_point_down])
        num_column_down = sum([(len(i) - 1) for i in column_point_down])
        num_row_up = sum([(len(i) - 1) for i in row_point_up])
        num_column_up = sum([(len(i) - 1) for i in column_point_up])

        num_fugan = len(points_fugan) * 4

        total = num_points + num_row_down + num_column_down + num_row_up + num_column_up + num_fugan

        self.change_value.emit(100, 0, '绘制节点')
        # 绘制节点坐标，以圆表示
        r = float(r)

        for item in circle_all:

            center = vtpnt(item[3], item[4], 0)
            if labels == 'labels':
                color = index_to_color_labels[item[5]]
            elif labels == 'row':
                color = index_to_color[item[1]]
            else:
                color = index_to_color[item[2]]

            circleObj = msp.AddCircle(center, r)
            clr.SetRGB(color[0], color[1], color[2])
            circleObj.TrueColor = clr
            circleObj.Layer = layername[0] if item[5] == 'down' else layername[1]
        the_num = num_points
        self.change_value.emit(total, the_num, '绘制下弦杆')

        # 绘制标签

        if labels == 'labels':
            draw_labels1(max_x=max_x, r_labels=r, labels_list=labels_list, index_to_color=index_to_color_labels, msp=msp,
                        layername=layername, clr=clr, distance_down_x=distances_down_dx)
        elif labels == 'row':
            draw_labels1(max_x=max_x, r_labels=r, labels_list=row_list, index_to_color=index_to_color, msp=msp,
                        layername=layername, clr=clr, distance_down_x=distances_down_dx)
        else:
            draw_labels1(max_x=max_x, r_labels=r, labels_list=column_list, index_to_color=index_to_color, msp=msp,
                        layername=layername, clr=clr, distance_down_x=distances_down_dx)

        # 绘制上下弦杆、腹杆

        # 绘上下弦杆
        drawpline_row(row_point_down, msp, clr, cr_value[2], layername[2], r)
        the_num += num_row_down
        self.change_value.emit(total, the_num, '绘制下弦杆')
        drawpline_column(column_point_down, msp, clr, cr_value[2], layername[2], r)
        the_num += num_column_down
        self.change_value.emit(total, the_num, '绘制上弦杆')
        drawpline_row(row_point_up, msp, clr, cr_value[0], layername[3], r)
        the_num += num_column_up
        self.change_value.emit(total, the_num, '绘制上弦杆')
        drawpline_column(column_point_up, msp, clr, cr_value[0], layername[3], r)
        the_num += num_column_up
        self.change_value.emit(total, the_num, '绘制腹杆')

        # 绘制腹杆
        for data_value in points_fugan:
            # 计算角度,并将数据转化为左下逆时针:左下开始，右下，右上，左上
            point5_five, angle_four = dealwithpoints1(data_value)
            # 绘制腹杆
            draw_fugan1(item=point5_five, msp=msp, clr=clr, layername=layername[4], angle_four=angle_four,
                       cr_value=cr_value[1], r=r)

        doc.Application.ZoomAll()  # 将图最适合展示
        doc.Application.Update()

        the_num = total
        self.change_value.emit(total, the_num, '绘制完成')


class DemoThread(QThread):
    change_value1 = pyqtSignal(int, int, str, int, int)
    change_value2 = pyqtSignal(str)
    change_value3 = pyqtSignal(int, int)

    def get_args(self, config, video_path, checkpoint, name_model, classes, score_th, loss_th, save_path,
                 Splicing_direction, save_picture, base_point, angle_use, d_frame, rc_th):
        self.config = config
        self.video_path = video_path
        self.checkpoint = checkpoint
        self.name_model = name_model
        self.classes = classes
        self.score_th = score_th
        self.loss_th = loss_th
        self.save_path = save_path
        self.direction = Splicing_direction
        self.save_picture = save_picture
        self.base_point = base_point
        self.angle_use = angle_use
        self.d_frame = d_frame
        self.rc_th = rc_th

    def run(self):
        config_file = self.config
        input_video = self.video_path
        checkpoint_file = self.checkpoint
        name = self.name_model
        classes = self.classes
        classes = int(classes)
        score_th = self.score_th
        score_th = float(score_th)
        loss_th = self.loss_th
        loss_th = float(loss_th)
        d_frame = self.d_frame
        d_frame = int(d_frame) + 1
        rc_th = self.rc_th
        rc_th = float(rc_th)

        self.change_value2.emit('请稍等')
        self.change_value3.emit(100, 0)

        model = init_detector(config_file, checkpoint_file, device=device)
        visualizer = VISUALIZERS.build(model.cfg.visualizer)
        # the dataset_meta is loaded from the checkpoint and
        # then pass to the model in init_detector
        visualizer.dataset_meta = model.dataset_meta
        global pgb_total, frame_id, html_before_path, html_after_path, messeges_before, messeges_after

        imgs = mmcv.VideoReader(input_video)
        pgb_total = len(imgs) - (len(imgs) % d_frame)

        prog_bar = mmengine.ProgressBar(len(imgs))
        vid = cv2.VideoCapture(input_video)
        w, h = vid.get(cv2.CAP_PROP_FRAME_WIDTH), vid.get(cv2.CAP_PROP_FRAME_HEIGHT)
        # 对视频逐帧处理

        # 创建临时文件夹，存放每帧结果
        temp_out_dir = self.save_path + '/' + time.strftime('%Y%m%d%H%M%S')
        os.mkdir(temp_out_dir)
        temp_out_dir_combine = temp_out_dir + '_combine'
        temp_out_dir_original = temp_out_dir + '_original'
        match_path = temp_out_dir + '_match'
        os.mkdir(temp_out_dir_combine)
        os.mkdir(temp_out_dir_original)
        os.mkdir(match_path)

        print('创建文件夹 {} 用于存放每帧预测结果'.format(temp_out_dir))
        print('创建文件夹 {} 用于存放每帧原图与预测图合并结果'.format(temp_out_dir_combine))
        print('创建文件夹 {} 用于存放每帧原图'.format(temp_out_dir_original))

        # 创建json文件
        json_path = self.save_path + '/' + time.strftime('%Y%m%d%H%M%S') + 'log.json'
        f = open(json_path, 'w')

        last_method = []
        angle_sum = 0
        angle_sum_truth = 0
        before_img = None
        sum_dx_before, sum_dy_before, dsumx_b, dsumy_b = 0, 0, 0, 0

        label_id = dict()
        before_result = []
        mat_frame_id_before = []
        angle_single_before = 0
        con_target_before = []
        dx_b, dy_b = 0, 0

        frame_use = 0
        for frame_id, img in enumerate(imgs):
            if frame_id % d_frame == 0:
                # print('\n---{}---'.format(frame_id))
                # 处理单帧画面
                cv2.imwrite(f'{temp_out_dir_original}/{frame_id:06d}.jpg', img)
                result = inference_detector(model, img)
                # print(type(result))
                # # print(result)
                # print(result.pred_instances)
                # print(result.pred_instances.scores)
                # print(result.pred_instances.scores[0].item())
                # print(len(result.pred_instances.scores))
                # img_after = pred_single_frame(model, result, img, w, h, score_thre=score_th, text_size=30)
                img_result = each_frame2(result, classes, frame_id, score_th, w, h)

                # 修正图片坐标
                if frame_id == 0:
                    # 首帧先确定id
                    img_result, label_id = single_retarget(img_result, loss_th)
                    visualizer.add_datasample('result', img, data_sample=result, draw_gt=False, wait_time=0, out_file=f'{temp_out_dir}/{frame_use:06d}.jpg', pred_score_thr=score_th)

                    # 将id绘制上去
                    img_after = pred_single_frame(img_result, img_path=f'{temp_out_dir}/{frame_use:06d}.jpg', text_size=30)
                    cv2.imwrite(f'{temp_out_dir}/{frame_use:06d}.jpg', img_after)
                    # 纵向连接
                    if self.direction == '纵向拼接':
                        images = np.vstack((img, img_after))
                        hh, ww = images.shape[:2]
                        cv2.imwrite(f'{temp_out_dir_combine}/{frame_use:06d}.jpg', images)
                        imge_show = f'{temp_out_dir_combine}/{frame_use:06d}.jpg'
                    else:
                        images = np.concatenate([img, img_after], axis=1)
                        hh, ww = images.shape[:2]
                        cv2.imwrite(f'{temp_out_dir_combine}/{frame_use:06d}.jpg', images)
                        imge_show = f'{temp_out_dir_combine}/{frame_use:06d}.jpg'

                    angle_single = 0
                    angle_truth = 0
                    angle_sum += angle_single
                    angle_sum_truth += angle_truth

                    mat_frame_id = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]

                    before_img = img
                    before_result = copy.deepcopy(img_result)

                    angle_single_before = angle_single
                    mat_frame_id_before = mat_frame_id
                    dx_b, dy_b = 0, 0
                    con_target_before = [0, 0, 0, 0]

                    last_method = world_coordinate_mat(img_result, mat_frame_id)
                    data = {"frame_id": frame_id, "angle_before": [0,0], "angle_start": [0,0], "原点世界坐标": [0, 0]}
                    json.dump(data, f, ensure_ascii=False)
                    f.write('\n')

                else:
                    if len(img_result) == 1:
                        before_img = before_img
                        before_result = before_result
                        angle_single_before = angle_single_before
                        mat_frame_id_before = mat_frame_id_before
                        dx_b, dy_b = dx_b, dy_b
                    else:

                        result_list, img_match = picture_result(before_img, img)
                        cv2.imwrite(f'{match_path}/{frame_id:06d}.jpg', img_match)
                        # ['frame_id', 'labels', 'the_id', 'xmin', 'ymin', 'xmax', 'ymax', '置信度', 'x_center', 'y_center']

                        img_result, last_labels_id, dx, dy, con_target_detection = upgrade_id1(before_result, img_result, loss_th, h, dx_b, dy_b)

                        result_id = copy.deepcopy(img_result)
                        angle_th = 1
                        angle_truth, angle_single, con_target = frame_angle(result_list, angle_single_before, con_target_before,
                                                               img_match, self.save_path, f, w, angle_th, loss_th)
                        angle_sum += angle_single
                        angle_sum_truth += angle_truth

                        if self.angle_use == '不使用角度':
                            angle_sum = 0
                        if self.base_point == 'SIFT共同目标':
                            mat_frame_id = compute_sum_dxdy_mat(con_target, mat_frame_id_before, angle_sum)
                        elif self.base_point == '检测共同目标':
                            mat_frame_id = compute_sum_dxdy_mat_detection(con_target_detection, mat_frame_id_before, angle_sum)
                        else:
                            mat_frame_id = compute_sum_dxdy_mat_dxdy(mat_frame_id_before, angle_sum, dx, dy)

                        before_img = img

                        angle_single_before = angle_single
                        mat_frame_id_before = mat_frame_id
                        con_target_before = con_target
                        dx_b, dy_b = dx, dy

                        # ['frame_id', 'labels', 'the_id', 'x_world', 'y_wold', 'x_center', 'y_center', 'x_base', 'y_base', 'row', 'column']
                        resultt = world_coordinate_mat(img_result, mat_frame_id)


                        resultt = upgrade_id(resultt, last_method, label_id, loss_th, last_labels_id)
                        # print(resultt)



                        for i in range(1, len(result_id)):
                            if result_id[i][2] == 0:
                                result_id[i][2] = resultt[i][2]
                        before_result = result_id
                        for i in range(1, len(resultt)):
                            last_method.append(resultt[i])

                        visualizer.add_datasample('result', img, data_sample=result, draw_gt=False, wait_time=0,
                                                  out_file=f'{temp_out_dir}/{frame_use:06d}.jpg',
                                                  pred_score_thr=score_th)
                        img_after = pred_single_frame(result_id, img_path=f'{temp_out_dir}/{frame_use:06d}.jpg',
                                                      text_size=30)
                        cv2.imwrite(f'{temp_out_dir}/{frame_use:06d}.jpg', img_after)
                        # 纵向连接
                        if self.direction == '纵向拼接':
                            images = np.vstack((img, img_after))
                            hh, ww = images.shape[:2]
                            cv2.imwrite(f'{temp_out_dir_combine}/{frame_use:06d}.jpg', images)
                            imge_show = f'{temp_out_dir_combine}/{frame_use:06d}.jpg'
                        else:
                            images = np.concatenate([img, img_after], axis=1)
                            hh, ww = images.shape[:2]
                            cv2.imwrite(f'{temp_out_dir_combine}/{frame_use:06d}.jpg', images)
                            imge_show = f'{temp_out_dir_combine}/{frame_use:06d}.jpg'

                        # print(con_target)
                        data = {"frame_id": frame_id, "angle_before": [angle_single,angle_truth], "angle_start": [angle_sum,angle_sum_truth], "原点世界坐标":[mat_frame_id[0][2], mat_frame_id[1][2]],
                                "共同坐标": con_target}
                        json.dump(data, f, ensure_ascii=False)
                        f.write('\n')

                self.change_value1.emit(pgb_total, frame_id + 1, imge_show, ww, hh)
                frame_use += 1
            prog_bar.update()  # 更新进度条


        # 把每一帧串成视频文件
        # self.change_value2.emit('检测单帧串成视频')
        # mmcv.frames2video(temp_out_dir, self.save_path + '/' + name + '_infer_result_out.mp4',
        #                   fps=imgs.fps, fourcc='mp4v')  # 更改输出文件名称
        # self.change_value2.emit('合并单帧串成视频')
        # mmcv.frames2video(temp_out_dir_combine, self.save_path + '/' + name + '_combine_result_out.mp4',
        #                   fps=imgs.fps, fourcc='mp4v')
        if self.save_picture == '不保存图像':
            shutil.rmtree(temp_out_dir)  # 删除存放每帧画面的临时文件夹
            shutil.rmtree(temp_out_dir_combine)
            shutil.rmtree(temp_out_dir_original)
            shutil.rmtree(match_path)

        # 使用id去重
        move_center_id = copy.deepcopy(last_method)
        output_data_id = [['frame_id', 'labels', 'the_id', 'x_world', 'y_world']]

        point_nums = 0
        while len(move_center_id) != 1:
            each_class = []
            point_nums += 1
            print('-----第{}个目标去重-----'.format(point_nums))
            self.change_value2.emit('第{}个目标去重'.format(point_nums))
            start = time.time()
            each_class.append(move_center_id[1])
            label = each_class[0][1]
            id = each_class[0][2]
            get_target_index = [label, id]
            for i in range(2, len(move_center_id)):
                if [label, id] == [move_center_id[i][1], move_center_id[i][2]]:
                    each_class.append(move_center_id[i])

            # 更新move_center_id，即删除刚计算的那个目标
            new_move_center_id = [move_center_id[0]]
            for i in range(1, len(move_center_id)):
                if [move_center_id[i][1], move_center_id[i][2]] != get_target_index:
                    new_move_center_id.append(move_center_id[i])

            # 同一目标坐标取均值

            ouput_datas, info_xy = each_class_avarage(each_class)
            output_data_id.append(ouput_datas)

            move_center_id = new_move_center_id

            end = time.time()
            print('第{}个目标重复量：{},去重耗时：{}'.format(point_nums, len(each_class), end - start))
            data = {"target": point_nums, "labels&id": [each_class[0][1], each_class[0][2]], "re_nums": len(each_class),
                    "runtime": end - start, "xy_coordinate": info_xy}
            json.dump(data, f, ensure_ascii=False)
            f.write('\n')

        #['frame_id', 'labels', 'the_id', 'x_world', 'y_wold', 'x_center', 'y_center', 'x_base', 'y_base']
        #['frame_id', 'labels', 'the_id', 'x_world', 'y_world']
        relative = [['the_id', 'correlation']]
        for i in range(1, len(output_data_id)):
            the_id = output_data_id[i][2]
            x_world, y_world = output_data_id[i][3], output_data_id[i][4]
            dd = 0
            t = 0
            for j in range(1, len(last_method)):
                if last_method[j][2] == the_id:
                    dd += (last_method[j][3] - x_world) ** 2 + (last_method[j][4] - y_world) ** 2
                    t += 1
            dd = dd / t
            relative.append([the_id, dd])
        sum = 0
        for i in range(1, len(relative)):
            sum += relative[i][1]
        sum = sum / (len(relative) - 1)
        #获得基点坐标
        base_xy = [['base_x', 'base_y']]

        for i in range(1, len(relative)):
            for j in range(1, len(last_method)):
                if relative[i][0] == last_method[j][2]:
                    base_xy.append([last_method[i][7], last_method[i][8]])
                    break

        global after_list
        after_list = [['frame_id', 'labels', 'the_id', 'x_world', 'y_world', 'correlation', 'base_x', 'base_y', 'row', 'column']]
        # print(len(output_data_id), len(relative), len(base_xy))
        for i in range(1, len(output_data_id)):
            after_list.append([output_data_id[i][0], output_data_id[i][1], output_data_id[i][2], output_data_id[i][3],
                               output_data_id[i][4], relative[i][1], base_xy[i][0], base_xy[i][1], 0, 0])
        # 确定行列号 思路从小到大排序，当前值减前一个值，结果小于loss_th说明同一行列，大于行列递增
        index_r = []
        for i in range(1, len(after_list)):
            index_r.append([i, after_list[i][4]])
        index_r = sorted(index_r, key=lambda x: x[1])
        index_c = []
        for i in range(1, len(after_list)):
            index_c.append([i, after_list[i][3]])
        index_c = sorted(index_c, key=lambda x: x[1])
        index_rows = compute_row_column(index_r, rc_th)
        for i in range(1, len(after_list)):
            for j in range(len(index_rows)):
                if i == index_rows[j][0]:
                    after_list[i][8] = index_rows[j][1]
                    break
        index_columns = compute_row_column(index_c, rc_th)
        for i in range(1, len(after_list)):
            for j in range(len(index_columns)):
                if i == index_columns[j][0]:
                    after_list[i][9] = index_columns[j][1]
                    break

        labels_before = []
        labels_before.append([last_method[i][1] for i in range(1, len(last_method))])
        labels_before = [i for j in labels_before for i in j]

        messeges_before, data = statistic_messeges(labels_before)
        print('messeges_before:', messeges_before)
        data = {"info_before": data}
        json.dump(data, f)


        labels_after = []
        labels_after.append([after_list[i][1] for i in range(1, len(after_list))])
        labels_after = [i for j in labels_after for i in j]

        messeges_after, data = statistic_messeges(labels_after)
        print('messeges_after:', messeges_after)
        data = {"info_after": data}
        json.dump(data, f, ensure_ascii=False)
        f.write('\n')
        f.close()

        # plotly可视化：降重前 ['frame_id', 'labels', 'the_id', 'x_world', 'y_wold']

        df = pd.DataFrame()
        df['frame_id'] = [last_method[i][0] for i in range(1, len(last_method))]
        df['labels'] = [last_method[i][1] for i in range(1, len(last_method))]
        df['the_id'] = [last_method[i][2] for i in range(1, len(last_method))]
        df['x_world'] = [last_method[i][3] for i in range(1, len(last_method))]
        df['y_world'] = [last_method[i][4] for i in range(1, len(last_method))]
        df['x_center'] = [last_method[i][5] for i in range(1, len(last_method))]
        df['y_center'] = [last_method[i][6] for i in range(1, len(last_method))]
        df['x_base'] = [last_method[i][7] for i in range(1, len(last_method))]
        df['y_base'] = [last_method[i][8] for i in range(1, len(last_method))]
        class_list = np.unique(df['labels'])
        n_class = len(class_list)  # 测试集标签类别数
        palette = sns.hls_palette(n_class)  # 配色方案
        # 随机打乱颜色列表和点型列表

        random.seed(1234)
        marker_list = ['.', ',', 'o', 'v', '^', '<', '>', '1', '2', '3', '4', '8', 's', 'p', 'P', '*', 'h', 'H', '+',
                       'x', 'X', 'D', 'd', '|', '_', 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
        random.shuffle(marker_list)
        random.shuffle(palette)
        show_feature = 'labels'
        # 二维交互式可视化plotly
        fig = px.scatter(df,
                         x='x_world',
                         y='y_world',
                         color=show_feature,
                         labels=show_feature,
                         symbol=show_feature,
                         hover_name='the_id',
                         opacity=0.8,
                         width=width,
                         height=height
                         )
        # 设置排版
        fig.update_layout(margin=dict(l=0, r=0, b=0, t=0))
        html_before_path = self.save_path + '/' + name + '_plotly_before.html'
        df.to_csv(self.save_path + '/' + name + '_world_xy_before.csv')
        fig.write_html(html_before_path)

        # plotly可视化：降重后
        df_after = pd.DataFrame()
        df_after['frame_id'] = [after_list[i][0] for i in range(1, len(after_list))]
        df_after['labels'] = [after_list[i][1] for i in range(1, len(after_list))]
        df_after['the_id'] = [after_list[i][2] for i in range(1, len(after_list))]
        df_after['x_world'] = [after_list[i][3] for i in range(1, len(after_list))]
        df_after['y_world'] = [after_list[i][4] for i in range(1, len(after_list))]
        df_after['correlation'] = [after_list[i][5] for i in range(1, len(after_list))]
        df_after['base_x'] = [after_list[i][6] for i in range(1, len(after_list))]
        df_after['base_y'] = [after_list[i][7] for i in range(1, len(after_list))]
        df_after['row'] = [after_list[i][8] for i in range(1, len(after_list))]
        df_after['column'] = [after_list[i][9] for i in range(1, len(after_list))]
        fig = px.scatter(df_after,
                         x='x_world',
                         y='y_world',
                         color=show_feature,
                         labels=show_feature,
                         symbol=show_feature,
                         hover_name='the_id',
                         opacity=0.8,
                         width=width,
                         height=height
                         )
        # 设置排版
        fig.update_layout(margin=dict(l=0, r=0, b=0, t=0))
        html_after_path = self.save_path + '/' + name + '_plotly_after.html'
        fig.write_html(html_after_path)

        after_list.append([1, 1, 1, 1, 'average', sum, 1, 1, 1, 1])
        df_after1 = pd.DataFrame()
        df_after1['frame_id'] = [after_list[i][0] for i in range(1, len(after_list))]
        df_after1['labels'] = [after_list[i][1] for i in range(1, len(after_list))]
        df_after1['the_id'] = [after_list[i][2] for i in range(1, len(after_list))]
        df_after1['x_world'] = [after_list[i][3] for i in range(1, len(after_list))]
        df_after1['y_world'] = [after_list[i][4] for i in range(1, len(after_list))]
        df_after1['correlation'] = [after_list[i][5] for i in range(1, len(after_list))]
        df_after1['base_x'] = [after_list[i][6] for i in range(1, len(after_list))]
        df_after1['base_y'] = [after_list[i][7] for i in range(1, len(after_list))]
        df_after1['row'] = [after_list[i][8] for i in range(1, len(after_list))]
        df_after1['column'] = [after_list[i][9] for i in range(1, len(after_list))]
        df_after1.to_csv(self.save_path + '/' + name + '_world_xy_after.csv')
        self.change_value2.emit('完成')


class Generatepkl(QThread):
    change_value = pyqtSignal(int)

    def get_args(self, config, best_checkpoint, train_result_file):
        self.config = config
        self.best_checkpoint = best_checkpoint
        self.train_result_file = train_result_file

    def run(self):
        config = self.config
        best_checkpoint = self.best_checkpoint
        train_result_file = self.train_result_file

        args_test = test_parse_args()

        args_test.config = config
        args_test.checkpoint = best_checkpoint
        args_test.work_dir = train_result_file
        args_test.out = train_result_file + '/out.pkl'

        test_main(args=args_test)
        self.change_value.emit(1)


class Demo(QTabWidget):
    video_path = None
    choice = '横向拼接'
    choice_list = ['纵向拼接']
    choices = '保存图像'
    choice_lists = ['不保存图像']
    choice_base = 'SIFT共同目标'
    choice_base_list = ['检测共同目标', 'dx_dy']
    choice_angle = '不使用角度'
    choice_angle_list = ['使用角度']

    def __init__(self):
        super(Demo, self).__init__()
        self.resize(700, 600)

        self.setWindowTitle("检测工具")
        self.tab0 = QWidget()
        self.tab1 = QWidget()
        self.tab2 = QWidget()
        self.tab3 = QWidget()
        self.tab4 = QWidget()
        self.tab5 = QWidget()
        self.tab6 = QWidget()

        self.tab0_init()
        self.tab1_init()
        self.tab2_init()
        self.tab3_init()
        self.tab4_init()
        self.tab5_init()
        self.tab6_init()

        # self.addTab(self.tab0, '面板介绍')
        self.addTab(self.tab1, '模型训练')
        self.addTab(self.tab2, '模型检测')
        self.addTab(self.tab3, '检测效果')
        self.addTab(self.tab4, '检测结果可视化')
        self.addTab(self.tab5, '图纸参数化')
        self.addTab(self.tab6, '绘入CAD')
        # self.tab1.setEnabled(False)

        # self.currentChanged.connect(self.on_tab_changed)

    # def on_tab_changed(self, tabIndex):
    #     #激活训练面板，冻结其他面板
    #     if tabIndex == 1:
    #         for i in range(2, self.count()):
    #             self.setTabEnabled(i, False)
    #     # 激活推理相关面板，冻结其他
    #     elif tabIndex == 2 or tabIndex == 3 or tabIndex == 4:
    #         for i in [1, 5, 6]:
    #             self.setTabEnabled(i, False)
    #     # 激活参数化面板，冻结其他
    #     elif tabIndex == 5 or tabIndex == 6:
    #         for i in range(1, 5):
    #             self.setTabEnabled(i, False)

    # 面板控件初始化
    def tab0_init(self):
        texts = '面板介绍：\n\n1.GUI的tab面板分为三大模块；\n\n2.模块1包含“模型训练”；\n\n3.模块2包含“模型检测”、“检测效果”、“检测结果可视化”；\n\n4.模块3包含“图纸参数化”、“结果修正”；\n\n5.选择模块后，其余模块将被冻结，欲使用须关闭后再次运行；\n\n6.使用推荐：模块1独立使用；先模块2再模块3。'
        self.tab0_qlable = QLabel(texts, self.tab0)
        self.tab0_qlable.setFont(QFont("Timers", 13, QFont.Bold))
        self.tab0_layout = QGridLayout()
        self.tab0_layout.addWidget(self.tab0_qlable, 0, 0, 1, 1, Qt.AlignHCenter)
        self.tab0.setLayout(self.tab0_layout)

    def tab1_init(self):
        self.classname = QLabel('训练种类：', self.tab1)
        self.classname_line = QLineEdit(self.tab1)
        self.classname_line.setPlaceholderText('例如：a,b,c')
        self.train_val = QLabel('训练验证比例：', self.tab1)
        self.train_val_line = QLineEdit(self.tab1)
        self.train_val_line.setPlaceholderText('例如：0.9:0.1')
        self.tococo_data_bt = QPushButton('转换数据格式', self.tab1)

        self.checkpoint_train = QPushButton('预训练模型权重', self.tab1)
        self.checkpoint_train_line = QLineEdit(self.tab1)
        self.checkpoint_train_line.setPlaceholderText('可根据需要选择预训练权重')
        self.config_file = QPushButton('配置文件', self.tab1)
        self.config_line = QLineEdit(self.tab1)
        self.config_line.setText(
            'E:/mmdetection/configs/1points/atss_r50_fpn_1x_points.py')
        self.config_line.setPlaceholderText('输入或加载待训练模型的配置文件（.py）')
        # self.config_line.setText('E:/CNN/pycharm2017/mmdetection/configs/yolof/yolof_r50_c5_8x8_1x_coco.py')
        self.train_result = QPushButton('训练文件保存路径', self.tab1)
        self.train_result_line = QLineEdit(self.tab1)
        self.train_result_line.setText('E:/mmdetection/configs/1points/train_result/atss')
        self.train_result_line.setPlaceholderText('用于保存训练日志、权重、loss曲线、PR曲线等文件的文件夹')

        # 添加触发训练函数的按钮
        self.train_btn = QPushButton('开始训练', self.tab1)
        self.train_btn.setToolTip('训练时间很长，至少数小时，甚至几十小时；\n训练的各种配置详见说明书，训练设置需要根据模型配置文件修改；')

        self.json_bt = QPushButton('训练日志文件（.json）', self.tab1)
        self.json_line = QLineEdit(self.tab1)
        self.json_line.setText('E:/mmdetection/configs/1points/train_result/atss/20230425_095108/vis_data/20230425_095108.json')
        self.bestpth_bt = QPushButton('训练好的权重文件')
        self.bestpth_line = QLineEdit(self.tab1)
        self.bestpth_line.setText('E:/mmdetection/configs/1points/train_result/atss/best_coco_bbox_mAP_epoch_12.pth')

        self.pkl_bt = QPushButton('生成.pkl', self.tab1)
        self.get_pkl_bt = QPushButton('加载.pkl文件')
        self.get_pkl_line = QLineEdit(self.tab1)
        self.get_pkl_line.setText('E:/mmdetection/configs/1points/train_result/atss/out.pkl')
        self.get_pkl_line.setPlaceholderText('若已经存在pkl，可直接加载，不用生成')

        self.plot_curve_bt = QPushButton('绘制曲线', self.tab1)

        self.tab1_layout = QGridLayout()

        self.tab1_layout_init()
        self.tab1_signal_init()

    def tab2_init(self):
        self.inputvideo_button = QPushButton('输入', self.tab2)
        self.inputvideo_line = QLineEdit(self.tab2)
        self.inputvideo_line.setText(
            'E:/mmdetection/demo/handup1_all.mp4')
        self.inputvideo_line.setPlaceholderText('输入待检测视频')

        self.modelconfile_button = QPushButton('配置文件', self.tab2)
        self.modelconfile_line = QLineEdit(self.tab2)
        self.modelconfile_line.setPlaceholderText('输入或加载推理模型的配置文件（.py）')

        self.checkpoint_demeo = QPushButton('加载模型权重')
        self.checkpoint_demo_line = QLineEdit(self.tab2)
        self.checkpoint_demo_line.setText(
            'E:/mmdetection/configs/1points/train_result/atss/best_coco_bbox_mAP_epoch_12.pth')
        self.checkpoint_demo_line.setPlaceholderText('用于检测（推理）视频的模型权重')

        self.save_after_video_button = QPushButton('保存', self.tab2)
        self.save_video_path = QLineEdit(self.tab2)
        self.save_video_path.setText('E:/mmdetection/configs/1points/result/handup_sift')
        self.save_video_path.setPlaceholderText('选择检测结果保存的文件夹')

        self.num_classes = QLabel('种类：', self.tab2)
        self.num_classes_line = QLineEdit(self.tab2)
        self.num_classes_line.setText('3')
        self.num_classes_line.setAlignment(Qt.AlignLeft)
        self.num_classes_line.setPlaceholderText('检测种类数')
        self.score_th = QLabel('置信度阈值：', self.tab2)
        self.score_th_line = QLineEdit(self.tab2)
        self.score_th_line.setText('0.3')
        self.score_th_line.setPlaceholderText('推荐0.3')
        self.px_th = QLabel('像素阈值：', self.tab2)
        self.px_th_line = QLineEdit(self.tab2)
        self.px_th_line.setText('100')
        self.px_th_line.setPlaceholderText('推荐100')

        self.pxrc_th = QLabel('行列间距：', self.tab2)
        self.pxrc_th_line = QLineEdit(self.tab2)
        self.pxrc_th_line.setText('200')
        self.pxrc_th_line.setPlaceholderText('小于最小节点间距')

        self.d_frame = QLabel('间隔帧数：', self.tab2)
        self.d_frame_line = QLineEdit(self.tab2)
        self.d_frame_line.setText('1')
        self.combobox_base_point = QComboBox(self.tab2)
        self.combobox_direction = QComboBox(self.tab2)
        self.combobox_picture = QComboBox(self.tab2)
        self.combobox_angle = QComboBox(self.tab2)

        self.predict_button = QPushButton('预测', self.tab2)

        self.progress = QProgressBar(self.tab2)
        self.progress.setMaximum(100)

        self.demo_result = QLabel(self.tab2)

        self.tab2_layout = QGridLayout()

        self.tab2_combobox_base_point_init()
        self.tab2_combobox_diret_init()
        self.tab2_combobox_picture_init()
        self.tab2_combobox_angle_init()

        self.tab2_layout_init()
        self.tab2_signal_init()

    def tab3_init(self):
        self.video_widget = QVideoWidget(self.tab3)
        self.player = QMediaPlayer(self.tab3)
        self.player.setVideoOutput(self.video_widget)

        self.open_button = QPushButton('打开', self.tab3)
        self.video_path = QLineEdit(self.tab3)
        self.video_path.setPlaceholderText('输入.mp4文件')

        # --播放按钮
        self.play_btn = QPushButton(self.tab3)
        self.play_btn.setIcon(QIcon(os.path.join(os.getcwd(), 'play.png')))
        self.play_btn.setIconSize(QSize(15, 15))
        self.play_btn.setStyleSheet('''QPushButton{border:none;}QPushButton:hover{border:none;border-radius:35px;}''')
        self.play_btn.setCursor(QCursor(Qt.PointingHandCursor))
        self.play_btn.setToolTip('播放')
        self.play_btn.setFlat(True)
        # --暂停按钮
        self.pause_btn = QPushButton('', self.tab3)
        self.pause_btn.setIcon(QIcon(os.path.join(os.getcwd(), 'pause.png')))
        self.pause_btn.setIconSize(QSize(15, 15))
        self.pause_btn.setStyleSheet('''QPushButton{border:none;}QPushButton:hover{border:none;}''')
        self.pause_btn.setCursor(QCursor(Qt.PointingHandCursor))
        self.pause_btn.setToolTip('暂停')
        self.pause_btn.setFlat(True)
        self.pause_btn.hide()
        # --播放进度
        self.play_progress_label = QLabel('00:00 / 00: 00', self.tab3)
        self.play_progress_slider = QSlider(Qt.Horizontal, self.tab3)
        self.play_progress_slider.setMinimum(0)
        self.play_progress_slider.setSingleStep(1)
        # self.play_progress_slider.setGeometry(QRect(0, 0, 200, 10))
        # --音量控制
        self.volume_slider = QSlider(Qt.Horizontal, self.tab3)
        self.volume_slider.setMinimum(0)
        self.volume_slider.setMaximum(100)
        self.volume_slider.setValue(50)
        self.mute_btn = QPushButton('', self.tab3)
        self.mute_btn.setIcon(QIcon(os.path.join(os.getcwd(), 'sound_on.png')))
        self.mute_btn.setIconSize(QSize(15, 15))
        self.mute_btn.setStyleSheet('''QPushButton{border:none;}QPushButton:hover{border:none;}''')
        self.mute_btn.setCursor(QCursor(Qt.PointingHandCursor))
        self.mute_btn.setToolTip('禁音')
        self.mute_btn.setFlat(True)
        self.volume_label = QLabel('50', self.tab3)

        self.tab3_layout = QGridLayout()

        self.tab3_layout_init()
        self.tab3_signal_init()

    def tab4_init(self):
        self.qwEngine = QWebEngineView(self.tab4)
        self.open1 = QPushButton('Open HTML File', self.tab4)
        self.open2 = QPushButton('降重前', self.tab4)
        self.open3 = QPushButton('降重后', self.tab4)
        self.messege_button = QPushButton('统计信息', self.tab4)
        self.messege_button.setEnabled(False)

        self.tab4_layout = QGridLayout()

        self.tab4_layout_init()
        self.tab4_signal_init()

    def tab5_init(self):
        self.classes_label = QLabel('可视化类别：', self.tab5)

        self.classes_line = QLineEdit(self.tab5)
        self.classes_line.setText('labels')

        self.classes_line.setPlaceholderText('labels或row或column')
        self.demoresult_bt = QPushButton('保存', self.tab5)
        self.demoresult_line = QLineEdit(self.tab5)
        self.demoresult_line.setPlaceholderText('与检测（推理）结果文件夹相同')

        self.open_dxf_button = QPushButton('Open DXF File', self.tab5)
        self.down_label = QLabel('下弦节点图层：', self.tab5)
        self.down_line = QLineEdit(self.tab5)
        self.down_line.setText('2')
        self.down_line.setToolTip(".dwg图中下弦节点所在图层的名称")
        self.up_label = QLabel('上弦节点图层：', self.tab5)
        self.up_line = QLineEdit(self.tab5)
        self.up_line.setText('1')
        self.up_line.setToolTip(".dwg图中上弦节点所在图层的名称")

        self.show_dxf = QPushButton('施工图可视化', self.tab5)
        self.show_dxf.setEnabled(False)
        self.messeges_bt_tab5 = QPushButton('统计信息', self.tab5)
        self.messeges_bt_tab5.setEnabled(False)

        self.qtengine_tab5 = QWebEngineView(self.tab5)

        self.tab5_layout = QGridLayout()

        self.tab5_layout_init()
        self.tab5_signal_init()

    def tab6_init(self):
        self.points_r_label = QLabel('节点半径：', self.tab6)
        self.points_r_line = QLineEdit(self.tab6)
        self.points_r_line.setPlaceholderText('推荐300')
        self.points_r_line.setText('100')

        self.first_points = QLabel('支座类型：', self.tab6)
        self.first_points_line = QLineEdit(self.tab6)
        self.first_points_line.setText('上弦节点')

        self.drawtocad_button = QPushButton('dxf参数化绘入CAD', self.tab6)
        self.drawtocad_button1 = QPushButton('检测结果绘入CAD', self.tab6)
        # self.drawtocad_button.setEnabled(False)
        self.drawtocad_button.setToolTip('点击前需打开CAD，新建一个dwg文件')

        self.cad_progress = QProgressBar(self.tab6)
        self.cad_progress.setMaximum(100)

        self.tab6_layout = QGridLayout()

        self.tab6_layout_init()
        self.tab6_signal_init()

    # 面板布局初始化

    def tab1_layout_init(self):
        self.tab1_layout.addWidget(self.classname, 0, 0, 1, 1)
        self.tab1_layout.addWidget(self.classname_line, 0, 1, 1, 1)
        self.tab1_layout.addWidget(self.train_val, 0, 2, 1, 1)
        self.tab1_layout.addWidget(self.train_val_line, 0, 3, 1, 1)
        self.tab1_layout.addWidget(self.tococo_data_bt, 0, 4, 1, 1)

        self.tab1_layout.addWidget(self.checkpoint_train, 1, 0, 1, 1)
        self.tab1_layout.addWidget(self.checkpoint_train_line, 1, 1, 1, 4)

        self.tab1_layout.addWidget(self.config_file, 2, 0, 1, 1)
        self.tab1_layout.addWidget(self.config_line, 2, 1, 1, 4)

        self.tab1_layout.addWidget(self.train_result, 3, 0, 1, 1)
        self.tab1_layout.addWidget(self.train_result_line, 3, 1, 1, 4)

        self.tab1_layout.addWidget(self.train_btn, 4, 0, 1, 5)

        self.tab1_layout.addWidget(self.json_bt, 5, 0, 1, 1)
        self.tab1_layout.addWidget(self.json_line, 5, 1, 1, 1)
        self.tab1_layout.addWidget(self.bestpth_bt, 5, 2, 1, 1)
        self.tab1_layout.addWidget(self.bestpth_line, 5, 3, 1, 2)

        self.tab1_layout.addWidget(self.pkl_bt, 6, 0, 1, 1)
        self.tab1_layout.addWidget(self.get_pkl_bt, 6, 1, 1, 1)
        self.tab1_layout.addWidget(self.get_pkl_line, 6, 2, 1, 3)

        self.tab1_layout.addWidget(self.plot_curve_bt, 7, 0, 1, 5)

        self.tab1.setLayout(self.tab1_layout)

    def tab2_layout_init(self):
        self.tab2_layout.addWidget(self.inputvideo_button, 0, 0, 1, 1)
        self.tab2_layout.addWidget(self.inputvideo_line, 0, 1, 1, 8)
        self.tab2_layout.addWidget(self.combobox_base_point, 0, 9, 1, 1)

        self.tab2_layout.addWidget(self.modelconfile_button, 1, 0, 1, 1)
        self.tab2_layout.addWidget(self.modelconfile_line, 1, 1, 1, 8)
        self.tab2_layout.addWidget(self.combobox_direction, 1, 9, 1, 1)

        self.tab2_layout.addWidget(self.checkpoint_demeo, 2, 0, 1, 1)
        self.tab2_layout.addWidget(self.checkpoint_demo_line, 2, 1, 1, 8)
        self.tab2_layout.addWidget(self.combobox_picture, 2, 9, 1, 1)

        self.tab2_layout.addWidget(self.save_after_video_button, 3, 0, 1, 1)
        self.tab2_layout.addWidget(self.save_video_path, 3, 1, 1, 8)
        self.tab2_layout.addWidget(self.combobox_angle, 3, 9, 1, 1)

        self.tab2_layout.addWidget(self.num_classes, 4, 0, 1, 1)
        self.tab2_layout.addWidget(self.num_classes_line, 4, 1, 1, 1)
        self.tab2_layout.addWidget(self.score_th, 4, 2, 1, 1)
        self.tab2_layout.addWidget(self.score_th_line, 4, 3, 1, 1)
        self.tab2_layout.addWidget(self.px_th, 4, 4, 1, 1)
        self.tab2_layout.addWidget(self.px_th_line, 4, 5, 1, 1)
        self.tab2_layout.addWidget(self.pxrc_th, 4, 6, 1, 1)
        self.tab2_layout.addWidget(self.pxrc_th_line, 4, 7, 1, 1)
        self.tab2_layout.addWidget(self.d_frame, 4, 8, 1, 1)
        self.tab2_layout.addWidget(self.d_frame_line, 4, 9, 1, 1)


        self.tab2_layout.addWidget(self.predict_button, 5, 0, 1, 1)
        self.tab2_layout.addWidget(self.progress, 5, 1, 1, 9)

        self.tab2_layout.addWidget(self.demo_result, 6, 0, 1, 10, Qt.AlignHCenter)

        self.tab2.setLayout(self.tab2_layout)

    def tab3_layout_init(self):
        self.tab3_layout.setSpacing(10)

        self.tab3_layout.addWidget(self.video_widget, 0, 0, 1, 5)

        self.tab3_layout.addWidget(self.open_button, 1, 0, 1, 1)
        self.tab3_layout.addWidget(self.video_path, 1, 1, 1, 1)
        self.tab3_layout.addWidget(self.mute_btn, 1, 2, 1, 1)
        self.tab3_layout.addWidget(self.volume_slider, 1, 3, 1, 1)
        self.tab3_layout.addWidget(self.volume_label, 1, 4, 1, 1)

        self.tab3_layout.addWidget(self.play_btn, 2, 0, 1, 1)
        self.tab3_layout.addWidget(self.pause_btn, 2, 0, 1, 1)
        self.tab3_layout.addWidget(self.play_progress_label, 2, 1, 1, 1)
        self.tab3_layout.addWidget(self.play_progress_slider, 2, 2, 1, 3)

        self.tab3.setLayout(self.tab3_layout)

    def tab4_layout_init(self):
        self.tab4_layout.addWidget(self.qwEngine, 0, 0, 1, 4)
        self.tab4_layout.addWidget(self.open1, 1, 0, 1, 1)
        self.tab4_layout.addWidget(self.open2, 1, 1, 1, 1)
        self.tab4_layout.addWidget(self.open3, 1, 2, 1, 1)
        self.tab4_layout.addWidget(self.messege_button, 1, 3, 1, 1)

        self.tab4.setLayout(self.tab4_layout)

    def tab5_layout_init(self):
        self.tab5_layout.addWidget(self.qtengine_tab5, 0, 0, 1, 7)  # 后面增加则失败Qt.AlignHCenter

        self.tab5_layout.addWidget(self.classes_label, 1, 0, 1, 1)
        self.tab5_layout.addWidget(self.classes_line, 1, 1, 1, 1)
        self.tab5_layout.addWidget(self.demoresult_bt, 1, 2, 1, 1)
        self.tab5_layout.addWidget(self.demoresult_line, 1, 3, 1, 4)

        self.tab5_layout.addWidget(self.down_label, 2, 0, 1, 1)
        self.tab5_layout.addWidget(self.down_line, 2, 1, 1, 1)
        self.tab5_layout.addWidget(self.up_label, 2, 2, 1, 1)
        self.tab5_layout.addWidget(self.up_line, 2, 3, 1, 1)
        self.tab5_layout.addWidget(self.open_dxf_button, 2, 4, 1, 1)
        self.tab5_layout.addWidget(self.show_dxf, 2, 5, 1, 1)
        self.tab5_layout.addWidget(self.messeges_bt_tab5, 2, 6, 1, 1)

        self.tab5.setLayout(self.tab5_layout)

    def tab6_layout_init(self):
        self.tab6_layout.addWidget(self.points_r_label, 0, 0, 1, 1)
        self.tab6_layout.addWidget(self.points_r_line, 0, 1, 1, 1)
        self.tab6_layout.addWidget(self.first_points, 0, 2, 1, 1)
        self.tab6_layout.addWidget(self.first_points_line, 0, 3, 1, 1)

        self.tab6_layout.addWidget(self.drawtocad_button, 1, 0, 1, 2)
        self.tab6_layout.addWidget(self.drawtocad_button1, 1, 2, 1, 2)

        self.tab6_layout.addWidget(self.cad_progress, 2, 0, 1, 4)

        self.tab6.setLayout(self.tab6_layout)

    # 面板信号初始化

    def tab1_signal_init(self):
        self.tococo_data_bt.clicked.connect(self.labelme_to_coco)
        # 线程定义两种方式：do_train1和do_train2
        self.train_btn.clicked.connect(lambda: self.do_train(config=self.config_line.text(),
                                                             train_result_file=self.train_result_line.text(),
                                                             pretrianed_checkpoint=self.checkpoint_train_line.text()))  # 只有epoch成功
        # self.train_btn.clicked.connect(self.train)
        self.checkpoint_train.clicked.connect(self.checkpointfile)
        self.config_file.clicked.connect(self.configfile)
        self.train_result.clicked.connect(self.trainresultfile)
        self.json_bt.clicked.connect(self.get_json_path)
        self.bestpth_bt.clicked.connect(self.get_best_pth_path)
        self.pkl_bt.clicked.connect(lambda: self.do_generate_pkl(config=self.config_line.text(),
                                                                 best_checkpoint=self.bestpth_line.text(),
                                                                 train_result_file=self.train_result_line.text()))
        # self.pkl_bt.clicked.connect(self.generate_pkl)
        # self.plot_curve_bt.clicked.connect(lambda: self.do_plot(config=self.config_line.text(),
        #                                                      json_file=self.json_line.text(),
        #                                                      save_path=self.train_result_line.text()))
        self.plot_curve_bt.clicked.connect(self.plot)
        self.get_pkl_bt.clicked.connect(self.get_pkl)

    def tab2_signal_init(self):
        self.inputvideo_button.clicked.connect(self.get_path1)
        self.modelconfile_button.clicked.connect(self.get_demo_config)
        self.checkpoint_demeo.clicked.connect(self.get_path2)
        # 解决每帧图片在gui不展示问题：
        # 1.使用子线程，完整版正常，但是在精简版报错
        # 2.不使用线程，在每帧图片展示后面加上QApplication.processEvents()，完整版精简版都正常
        # self.predict_button.clicked.connect(lambda: self.demo(video_path=self.inputvideo_line.text(),
        #                                                       checkpoint=self.checkpoint_demo_line.text(),
        #                                                       name_model=modole_name))
        self.predict_button.clicked.connect(
            lambda: self.do_demo(config=self.modelconfile_line.text(), video_path=self.inputvideo_line.text(),
                                 checkpoint=self.checkpoint_demo_line.text(), name_model=modole_name,
                                 classes=self.num_classes_line.text(), score_th=self.score_th_line.text(),
                                 loss_th=self.px_th_line.text(), save_path=self.save_video_path.text(),
                                 Splicing_direction=self.combobox_direction.currentText(),
                                 save_picture=self.combobox_picture.currentText(),
                                 base_point=self.combobox_base_point.currentText(),
                                 angle_use=self.combobox_angle.currentText(),
                                 d_frame=self.d_frame_line.text(),
                                 rc_th=self.pxrc_th_line.text()))
        self.save_after_video_button.clicked.connect(self.get_path3)

    def tab3_signal_init(self):
        self.player.durationChanged.connect(self.setVideoLength)
        self.player.positionChanged.connect(self.setPlayProgress)
        self.open_button.clicked.connect(self.openvideo)
        self.play_btn.clicked.connect(self.playvideo)
        self.pause_btn.clicked.connect(self.pausevideo)
        self.mute_btn.clicked.connect(self.mute)
        self.volume_slider.valueChanged.connect(self.setVolume)
        self.play_progress_slider.sliderPressed.connect(self.playProgressSliderPressed)
        self.play_progress_slider.sliderReleased.connect(self.playProgressSliderReleased)

    def tab4_signal_init(self):
        self.open1.clicked.connect(lambda: self.tab4_show_html(self.open1.text()))
        self.open2.clicked.connect(lambda: self.tab4_show_html(self.open2.text()))
        self.open3.clicked.connect(lambda: self.tab4_show_html(self.open3.text()))
        self.messege_button.clicked.connect(self.showMsg)

    def tab5_signal_init(self):
        # 使用线程
        self.demoresult_bt.clicked.connect(self.get_demoresult_path)
        self.open_dxf_button.clicked.connect(self.open_dxf)
        self.show_dxf.clicked.connect(self.plotlyshow_dxf)
        self.messeges_bt_tab5.clicked.connect(self.show_dxfMsg)

    def tab6_signal_init(self):
        self.drawtocad_button.clicked.connect(self.do_drawtocad)
        self.drawtocad_button1.clicked.connect(self.do_drawtocad1)

    def tab2_combobox_base_point_init(self):
        self.combobox_base_point.addItem(self.choice_base)
        self.combobox_base_point.addItems(self.choice_base_list)
    def tab2_combobox_diret_init(self):
        self.combobox_direction.addItem(self.choice)
        self.combobox_direction.addItems(self.choice_list)

    def tab2_combobox_picture_init(self):
        self.combobox_picture.addItem(self.choices)
        self.combobox_picture.addItems(self.choice_lists)
    def tab2_combobox_angle_init(self):
        self.combobox_angle.addItem(self.choice_angle)
        self.combobox_angle.addItems(self.choice_angle_list)
    # tab6槽函数
    # def start_cad(self): #使用精简版不支持CAD绘图，分离的绘图模块
    #     self.drawtocad_button.setText('请稍等')
    #     os.system('start ../demo/draw_cad.exe')  # 在pycharm启动，在demo下的.bat启动

    # 显示进度条
    def drawtocad1(self):
        self.drawtocad_button.setText('绘图中')
        self.cad_progress.setValue(100 * 0 / 100)
        QApplication.processEvents()

        # 对CAD的操作
        acad = win32com.client.Dispatch("AutoCAD.Application")
        # 显示AutoCAD界面
        doc = acad.ActiveDocument
        msp = doc.ModelSpace
        version = acad.Application.Version[:2]  # 当前CAD的版本号
        clr = acad.Application.GetInterfaceObject("AutoCAD.AcCmColor.%s" % version)
        # 新建图层
        layername = ['下弦杆节点', '上弦杆节点', '下弦杆', '上弦杆', '腹杆', '标签']  # 下弦杆节点，上弦杆节点，下弦杆，上弦杆，腹杆
        for item in layername:
            doc.Layers.Add(item)

        # 绘制节点坐标，以圆表示
        # global labels_list, row_list, column_list
        labels_list = ['down', 'up']
        row_list = np.unique(df_dxf['row'])
        column_list = np.unique(df_dxf['column'])
        classes_list = [row_list, column_list]
        classes_list = [x for l in classes_list for x in l]
        classes_list = list(set(classes_list))
        palette = sns.hls_palette(len(classes_list), l=0.1, h=0.9)  # 配色方案,默认0.3，变化幅度#亮度，色相
        # palette = sns.cubehelix_palette(len(classes_list), start=255, light=0.9, rot=-1.5)
        np.random.shuffle(palette)
        index_to_color = {classes_list[i]: [255 * palette[i][0], 255 * palette[i][1], 255 * palette[i][2]] for i in
                          range(len(classes_list))}
        index_to_color_labels = {'down': [0, 255, 255], 'up': [255, 0, 255]}
        max_x = max(map(lambda x: x[3], circle_all))
        labels = self.classes_line.text()

        # 杆件颜色
        cr_value = [[0, 0, 255], [0, 255, 0], [255, 0, 0]]  # 上弦杆，腹杆，下弦杆
        row_num_down = np.unique(df_down['row'])
        column_num_down = np.unique(df_down['column'])
        row_num_up = np.unique(df_up['row'])
        column_num_up = np.unique(df_up['column'])
        # 获得下弦杆行和列点
        row_point_down = getline_points_row(row_num_down, circle_xy_down)
        column_point_down = getline_points_column(column_num_down, circle_xy_down)
        # 获得上弦杆行和列点
        row_point_up = getline_points_row(row_num_up, circle_xy_up)
        column_point_up = getline_points_column(column_num_up, circle_xy_up)

        # 获得每个下弦杆节点周围四个上弦杆节点
        points_fugan = getpoints_fugan(circle_xy_down, circle_xy_up)
        pi = math.pi

        num_points = len(circle_all)
        num_row_down = sum([(len(i) - 1) for i in row_point_down])
        num_column_down = sum([(len(i) - 1) for i in column_point_down])
        num_row_up = sum([(len(i) - 1) for i in row_point_up])
        num_column_up = sum([(len(i) - 1) for i in column_point_up])

        num_fugan = len(points_fugan) * 4

        total = num_points + num_row_down + num_column_down + num_row_up + num_column_up + num_fugan

        global r
        r = self.points_r_line.text()  # 节点半径
        r = float(r)
        for item in circle_all:
            center = vtpnt(item[3], item[4], 0)
            if labels == 'labels':
                color = index_to_color_labels[item[0]]
            elif labels == 'row':
                color = index_to_color[item[1]]
            else:
                color = index_to_color[item[2]]

            circleObj = msp.AddCircle(center, r)
            clr.SetRGB(color[0], color[1], color[2])
            circleObj.TrueColor = clr
            circleObj.Layer = layername[0] if item[0] == 'down' else layername[1]
        the_num = num_points
        self.cad_progress.setValue(100 * the_num / total)
        QApplication.processEvents()
        # 绘制标签

        if labels == 'labels':
            draw_labels(max_x=max_x, r_labels=r, labels_list=labels_list, index_to_color=index_to_color_labels, msp=msp,
                        layername=layername, clr=clr)
        elif labels == 'row':
            draw_labels(max_x=max_x, r_labels=r, labels_list=row_list, index_to_color=index_to_color, msp=msp,
                        layername=layername, clr=clr)
        else:
            draw_labels(max_x=max_x, r_labels=r, labels_list=column_list, index_to_color=index_to_color, msp=msp,
                        layername=layername, clr=clr)

        # 绘制上下弦杆、腹杆

        # 绘上下弦杆
        drawpline_row(row_point_down, msp, clr, cr_value[2], layername[2])
        the_num += num_row_down
        self.cad_progress.setValue(100 * the_num / total)
        QApplication.processEvents()
        drawpline_column(column_point_down, msp, clr, cr_value[2], layername[2])
        the_num += num_column_down
        self.cad_progress.setValue(100 * the_num / total)
        QApplication.processEvents()
        drawpline_row(row_point_up, msp, clr, cr_value[0], layername[3])
        the_num += num_column_up
        self.cad_progress.setValue(100 * the_num / total)
        QApplication.processEvents()
        drawpline_column(column_point_up, msp, clr, cr_value[0], layername[3])
        the_num += num_column_up
        self.cad_progress.setValue(100 * the_num / total)
        QApplication.processEvents()

        # 绘制腹杆
        for data_value in points_fugan:
            # 计算角度,并将数据转化为左下逆时针:左下开始，右下，右上，左上
            point5_five, angle_four = dealwithpoints(data_value, pi)
            # 绘制腹杆
            draw_fugan(item=point5_five, msp=msp, clr=clr, layername=layername[4], angle_four=angle_four,
                       cr_value=cr_value[1])
        the_num = total
        self.cad_progress.setValue(100 * the_num / total)
        QApplication.processEvents()

        doc.Application.ZoomAll()  # 将图最适合展示
        doc.Application.Update()
        self.drawtocad_button.setText('完成')

    # 使用线程
    def do_drawtocad(self):
        self.thread6 = DrawtoCAD()
        self.thread6.get_args(points_r=self.points_r_line.text(), labels=self.classes_line.text())
        self.thread6.change_value.connect(self.setprogress_drawtocad)
        self.thread6.start()
    # 检测结果绘入CAD
    def do_drawtocad1(self):
        self.thread7 = Detect_drawtocad()
        self.thread7.get_args(points_r=self.points_r_line.text(), labels=self.classes_line.text(), data_all=after_list,
                              first_rc=self.first_points_line.text(), save_path=self.save_video_path.text())
        self.thread7.change_value.connect(self.setprogress_drawtocad1)
        self.thread7.start()
    def setprogress_drawtocad(self, total, the_num, text):
        self.drawtocad_button.setText(text)
        self.cad_progress.setValue(100 * the_num / total)
    def setprogress_drawtocad1(self, total, the_num, text):
        self.drawtocad_button1.setText(text)
        self.cad_progress.setValue(100 * the_num / total)
    # tab4槽函数
    def tab4_show_html(self, currentext):
        global messeges
        if currentext == 'Open HTML File':
            fileName, _ = QFileDialog.getOpenFileName(self, 'Open File', '', 'HTML Files (*.html)')
            if fileName != '':
                self.qwEngine.load(QUrl.fromLocalFile(fileName))
            self.messege_button.setEnabled(False)
        elif currentext == '降重前':
            fileName = html_before_path
            if fileName != '':
                self.qwEngine.load(QUrl.fromLocalFile(fileName))
            self.messege_button.setEnabled(True)
            messeges = "\n".join(messeges_before)
        else:
            fileName = html_after_path
            if fileName != '':
                self.qwEngine.load(QUrl.fromLocalFile(fileName))
            self.messege_button.setEnabled(True)
            messeges = "\n".join(messeges_after)

    def showMsg(self):
        self.msg = QMessageBox(self)
        self.msg.setWindowTitle('统计信息')
        self.msg.setText(messeges)
        self.msg.setStandardButtons(QMessageBox.Close)
        self.msg.buttonClicked.connect(self.msgBtn)
        self.msg.show()

    # tab4和5共有
    def msgBtn(self, i):
        if i.text() == 'Close':
            self.msg.close()

    # tab5槽函数
    def open_dxf(self):
        global message_dxf, circle_all, html_dxf_path, circle_xy_down, circle_xy_up
        fileName, _ = QFileDialog.getOpenFileName(self, 'Open File', '', 'DXF Files (*.dxf)')
        if fileName != '':
            dxf = dxfgrabber.readfile(fileName)
            circle_xy_down = []
            circle_xy_up = []
            for entity in dxf.entities:
                if entity.dxftype == 'CIRCLE' and (entity.layer == self.down_line.text()):
                    circle_xy_down.append(['down', 0, 0, entity.center[0], entity.center[1]])
                if entity.dxftype == 'CIRCLE' and (entity.layer == self.up_line.text()):
                    circle_xy_up.append(['up', 0, 0, entity.center[0], entity.center[1]])

            # 上弦杆修正
            # 将列表中每个子列表的第三个元素提取出来，存入新列表
            dx_list = []
            for item in circle_xy_up:
                if item[3] not in dx_list:
                    dx_list.append(item[3])
            # 对新列表排序，取最小的2个
            dx_list.sort()
            min_two_ux = dx_list[:2]

            uy_list = []
            for item in circle_xy_up:
                if item[4] not in uy_list:
                    uy_list.append(item[4])
            uy_list.sort()
            min_two_uy = uy_list[:2]

            min_x = min_two_ux[0]
            min_y = min_two_uy[0]
            # 减去最小值，变为原点开始
            for item in circle_xy_up:
                item[3] -= min_x
                item[4] -= min_y
            global distance_down_x
            # 上弦杆间距
            distance_up_x = min_two_ux[1] - min_two_ux[0]
            distance_up_y = min_two_uy[1] - min_two_uy[0]

            # 上弦杆行列修正
            the_row = []
            the_column = []
            for item in circle_xy_up:
                the_row.append(round(item[4] / distance_up_y))
                the_column.append(round(item[3] / distance_up_x))
            th_repeatx = find_value(the_row)
            while th_repeatx != 0:
                for i in range(len(the_row)):
                    if the_row[i] >= th_repeatx:
                        the_row[i] = the_row[i] - 1
                    else:
                        continue
                th_repeatx = find_value(the_row)

            th_repeaty = find_value(the_column)
            while th_repeaty != 0:
                for i in range(len(the_column)):
                    if the_column[i] >= th_repeaty:
                        the_column[i] = the_column[i] - 1
                    else:
                        continue
                th_repeaty = find_value(the_column)

            # 上弦杆行列修正
            for i in range(len(circle_xy_up)):
                circle_xy_up[i][1] = the_row[i]
                circle_xy_up[i][2] = the_column[i]

            # 下弦杆间距
            dx_list = []
            for item in circle_xy_down:
                if item[3] not in dx_list:
                    dx_list.append(item[3])
            dx_list.sort()
            min_two_dx = dx_list[:2]
            dy_list = []
            for item in circle_xy_down:
                if item[4] not in dy_list:
                    dy_list.append(item[4])
            dy_list.sort()
            min_two_dy = dy_list[:2]
            # 下弦杆间距
            distance_down_x = min_two_dx[1] - min_two_dx[0]
            distance_down_y = min_two_dy[1] - min_two_dy[0]

            # 下弦杆行列修正
            thedown_row = []
            thedown_column = []
            for item in circle_xy_down:
                thedown_row.append(round((item[4] - min_two_dy[0]) / distance_down_y))
                thedown_column.append(round((item[3] - min_two_dx[0]) / distance_down_x))

            thdown_repeatx = find_value(thedown_row)
            while thdown_repeatx != 0:
                for i in range(len(thedown_row)):
                    if thedown_row[i] >= thdown_repeatx:
                        thedown_row[i] = thedown_row[i] - 1
                    else:
                        continue
                thdown_repeatx = find_value(thedown_row)
            thdown_repeaty = find_value(thedown_column)
            while thdown_repeaty != 0:
                for i in range(len(thedown_column)):
                    if thedown_column[i] >= thdown_repeaty:
                        thedown_column[i] = thedown_column[i] - 1
                    else:
                        continue
                thdown_repeaty = find_value(thedown_column)

            for i in range(len(circle_xy_down)):
                circle_xy_down[i][1] = thedown_row[i]
                circle_xy_down[i][2] = thedown_column[i]

            global df_down, df_up
            df_down = pd.DataFrame()
            df_down['labels'] = [circle_xy_down[i][0] for i in range(0, len(circle_xy_down))]
            df_down['row'] = [circle_xy_down[i][1] for i in range(0, len(circle_xy_down))]
            df_down['column'] = [circle_xy_down[i][2] for i in range(0, len(circle_xy_down))]
            df_down['x_world'] = [circle_xy_down[i][3] for i in range(0, len(circle_xy_down))]
            df_down['y_world'] = [circle_xy_down[i][4] for i in range(0, len(circle_xy_down))]
            # df_down.to_csv(self.demoresult_line.text() + '/points_down.csv', index=False)

            df_up = pd.DataFrame()
            df_up['labels'] = [circle_xy_up[i][0] for i in range(0, len(circle_xy_up))]
            df_up['row'] = [circle_xy_up[i][1] for i in range(0, len(circle_xy_up))]
            df_up['column'] = [circle_xy_up[i][2] for i in range(0, len(circle_xy_up))]
            df_up['x_world'] = [circle_xy_up[i][3] for i in range(0, len(circle_xy_up))]
            df_up['y_world'] = [circle_xy_up[i][4] for i in range(0, len(circle_xy_up))]
            # df_up.to_csv(self.demoresult_line.text() + '/points_up.csv', index=False)

            global circle_all
            circle_all = pd.concat([pd.Series(circle_xy_down), pd.Series(circle_xy_up)], axis=0).tolist()
            # ['labels','row','column','x_world','y_world']

            text_list = []
            text_list.append(['所有节点数', str(len(circle_xy_down) + len(circle_xy_up))])
            text_list.append(['下弦杆节点数', str(len(circle_xy_down))])
            text_list.append(['上弦杆节点数', str(len(circle_xy_up))])

            message = ''
            for item in text_list:
                message += '{}: {}\n'.format(item[0], item[1])
            message_dxf = message

            global df_dxf
            df_dxf = pd.DataFrame()

            df_dxf['labels'] = [circle_all[i][0] for i in range(0, len(circle_all))]
            df_dxf['row'] = [circle_all[i][1] for i in range(0, len(circle_all))]
            df_dxf['column'] = [circle_all[i][2] for i in range(0, len(circle_all))]
            df_dxf['x_world'] = [circle_all[i][3] for i in range(0, len(circle_all))]
            df_dxf['y_world'] = [circle_all[i][4] for i in range(0, len(circle_all))]
            # df_dxf.to_csv(self.demoresult_line.text() + '/points_all.csv', index=False)

            marker_list = ['.', ',', 'o', 'v', '^', '<', '>', '1', '2', '3', '4', '8', 's', 'p', 'P', '*', 'h', 'H',
                           '+', 'x', 'X', 'D', 'd', '|', '_', 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
                           16, 17, 18, 19, 20]
            global labels
            labels = self.classes_line.text()
            labels_list = np.unique(df_dxf[labels])
            n_class = len(labels_list)  # 测试集标签类别数
            palette = sns.hls_palette(n_class)  # 配色方案
            sns.palplot(palette)
            random.seed(1234)
            random.shuffle(marker_list)
            random.shuffle(palette)

            # show_feature = 'labels'
            show_feature = labels
            # show_feature = 'column'
            fig = px.scatter(df_dxf,
                             x='x_world',
                             y='y_world',
                             color=show_feature,
                             labels=show_feature,
                             symbol=show_feature,
                             hover_name='labels',
                             opacity=0.8,  # 透明度参数0-1
                             width=width,
                             height=height
                             )
            # 设置排版
            fig.update_layout(margin=dict(l=0, r=0, b=0, t=0))
            html_dxf_path = self.demoresult_line.text() + '/plotly_dxf_' + show_feature + '.html'
            fig.write_html(html_dxf_path)
            self.show_dxf.setEnabled(True)
            self.messeges_bt_tab5.setEnabled(True)

            self.open_dxf_button.setText('完成')

    def plotlyshow_dxf(self):
        fileName = html_dxf_path
        if fileName != '':
            self.qtengine_tab5.load(QUrl.fromLocalFile(fileName))

    def show_dxfMsg(self):
        self.msg = QMessageBox(self)
        self.msg.setWindowTitle('统计信息')
        self.msg.setText(message_dxf)
        self.msg.setStandardButtons(QMessageBox.Close)
        self.msg.buttonClicked.connect(self.msgBtn)
        self.msg.show()

    def get_demoresult_path(self):
        path = QFileDialog.getExistingDirectory()
        self.demoresult_line.setText(path)

    # tab1槽函数
    def labelme_to_coco(self):

        classname = self.classname_line.text()
        # 转换为字典格式
        # classname_to_id = {"a": 1,"b": 2,"c": 3}
        sep1 = ','
        for item in classname:
            if item == ',' or item == '，':
                sep1 = item
                break
        str_list1 = classname.split(sep1)
        classname_to_id = {str_list1[i]: i + 1 for i in range(len(str_list1))}

        train_val = self.train_val_line.text()
        for item in train_val:
            if item == ':' or item == '：':
                sep2 = item
                train_val = [float(x) for x in train_val.split(sep2)]
                break

        data_path = QFileDialog.getExistingDirectory()

        self.tococo_data_bt.setText('转换中')
        QApplication.processEvents()

        labelme_coco_main(data_path, classname_to_id, train_val=train_val)
        self.tococo_data_bt.setText('转换完成')

    def checkpointfile(self):
        fileName, _ = QFileDialog.getOpenFileName(self, 'Open File', '', 'PTH Files (*.pth)')
        self.checkpoint_train_line.setText(fileName)

    def configfile(self):
        fileName, _ = QFileDialog.getOpenFileName(self, 'Open File', '', 'PY Files (*.py)')
        self.config_line.setText(fileName)

    def trainresultfile(self):
        path = QFileDialog.getExistingDirectory()
        self.train_result_line.setText(path)

    def get_json_path(self):
        fileName, _ = QFileDialog.getOpenFileName(self, '打开训练日志文件', '', 'JSON Files (*.json)')
        self.json_line.setText(fileName)

    def get_pkl(self):
        fileName, _ = QFileDialog.getOpenFileName(self, '打开.pkl文件', '', 'PKL Files (*.pkl)')
        self.get_pkl_line.setText(fileName)

    def get_best_pth_path(self):
        fileName, _ = QFileDialog.getOpenFileName(self, '打开最佳权重文件', '', 'PTH Files (*.pth)')
        self.bestpth_line.setText(fileName)

    # 线程定义方式
    def do_train(self, config, train_result_file, pretrianed_checkpoint):
        self.thread1 = TrainThread()
        self.thread1.get_args(a=config, b=train_result_file, c=pretrianed_checkpoint)
        self.thread1.change_value.connect(self.setTrain_infon)
        self.thread1.start()
        time.sleep(2)  # 2秒再显示
        self.train_btn.setText('训练中，训练信息请查看cmd')

    def setTrain_infon(self):
        self.train_btn.setText('训练完成')

    def do_generate_pkl(self, config, best_checkpoint, train_result_file):
        self.thread4 = Generatepkl()
        self.thread4.get_args(config, best_checkpoint, train_result_file)
        self.thread4.change_value.connect(self.setinfo_pkl)
        self.thread4.start()
        self.pkl_bt.setText('生成中')

    def setinfo_pkl(self):
        self.pkl_bt.setText('完成')


    def setinfo_plot(self):
        self.plot_curve_bt.setText('绘制完成')

    # 可以改成使用线程方式
    def plot(self):
        self.plot_curve_bt.setText('绘制中')
        QApplication.processEvents()

        # 为visualize量身打造.json文件
        file_log = open(self.json_line.text())
        count = 0
        loss_label = list()
        for line in file_log:
            if count == 1:
                the_second_line = json.loads(line)  # 第0行是环境等信息
                the_second_line_keys = list(the_second_line.keys())
                print(the_second_line_keys)
                loss_names = ["loss_rpn_cls", "loss_rpn_bbox", "loss_cls", "loss_bbox", "loss_centerness", "loss"]
                for item in the_second_line_keys:
                    if item in loss_names:
                        loss_label.append(item)
                if len(the_second_line_keys) == 13:
                    # 绘图名称、字体大小等等在里面更改
                    data_list = load_data(log=file_log)

                    # 保存为CSV数据
                    with open('1_loss_visualize.csv', 'w', newline='') as file:
                        writer = csv.writer(file)
                        writer.writerows(data_list)

                    show_chart(data_list, path=self.json_line.text(), font_size={'font.size': 15}, fig_size=(20, 20),
                               title_size=30)
                break
            count += 1

        loss_labels = list()
        loss_labels.append(loss_label)
        loss_labels.append(["coco/bbox_mAP", "coco/bbox_mAP_50", "coco/bbox_mAP_75", "coco/bbox_mAP_s", "coco/bbox_mAP_m", "coco/bbox_mAP_l"])
        print(loss_labels)

        plot_args = analyze_logs_parse_args()
        # 以下参数可以参考源码更改
        for i in range(2):
            plot_args.task = 'plot_curve'
            plot_args.json_logs = [self.json_line.text()]
            plot_args.keys = loss_labels[
                i]  # 'loss_cls', 'loss_bbox', 'loss'，"bbox_mAP", "bbox_mAP_50", "bbox_mAP_75", "bbox_mAP_s", "bbox_mAP_m", "bbox_mAP_l",可一个或多个
            plot_args.start_epoch = '1'
            plot_args.eval_interval = '1'
            title = 'AP-epoch' if i == 1 else 'loss-iter'
            plot_args.title = title
            plot_args.legend = None  # ['x','xx','xdf'],就是右上角每条曲线名称
            plot_args.backend = None  # 暂不清除用法
            style = 'ticks'
            plot_args.style = style  # white, dark, whitegrid有网格, darkgrid, ticks
            plot_args.out = self.train_result_line.text() + '/' + title + '_' + style + '.png'

            analyze_logs_main(args=plot_args)
        # PR曲线
        plot_pr_curve(config_file=self.config_line.text(), result_file=self.train_result_line.text() + '/out.pkl',
                      save_path=self.train_result_line.text(), metric="bbox")

        # 绘制混淆矩阵
        matrix_args = confusion_matrix_parse_args()
        matrix_args.config = self.config_line.text()
        matrix_args.prediction_path = self.train_result_line.text() + '/out.pkl'
        matrix_args.save_dir = self.train_result_line.text()
        matrix_args.show = False
        confusion_matrix_main(args=matrix_args)

        self.plot_curve_bt.setText('绘制完成')

    # 使用线程，没用到
    def generate_pkl(self):
        self.pkl_bt.setText('生成中')
        QApplication.processEvents()

        args_test = test_parse_args()

        args_test.config = self.config_line.text()
        args_test.checkpoint = self.bestpth_line.text()
        args_test.work_dir = self.train_result_line.text()
        args_test.out = self.train_result_line.text() + '/out.pkl'

        test_main(args=args_test)

        self.pkl_bt.setText('完成')

    def train(self):
        self.train_btn.setText('训练中')
        QApplication.processEvents()

        args_train = train_parser()
        # 获取用户设置的参数
        args_train.config = self.config_line.text()
        args_train.work_dir = self.train_result_line.text()
        args_train.load_from = self.checkpoint_train_line.text() if self.checkpoint_train_line.text() != '' else None

        train_main(args=args_train)

        self.train_btn.setText('训练完成')

    # tab2槽函数
    def get_path1(self):
        fileName, _ = QFileDialog.getOpenFileName(self, 'Open File', '', 'mp4 Files (*.mp4; *.avi; *.mkv)')
        self.inputvideo_line.setText(fileName)

    def get_demo_config(self):
        global modole_name
        fileName, _ = QFileDialog.getOpenFileName(self, 'Open File', '', 'PY Files (*.py)')
        self.modelconfile_line.setText(fileName)
        modole_name = fileName.split('/')[-2]

    def get_path2(self):
        fileName, _ = QFileDialog.getOpenFileName(self, 'Open File', '', 'PTH Files (*.pth)')
        self.checkpoint_demo_line.setText(fileName)

    def get_path3(self):
        # self.show_dxf.setEnabled(True)
        global after_infer_videopath
        path = QFileDialog.getExistingDirectory()
        after_infer_videopath = path
        self.save_video_path.setText(path)

    # 使用线程，使用线程建议将demo中self.demo_result.setPixmap(imge_show)下的QApplication.processEvents()删去
    def do_demo(self, config, video_path, checkpoint, name_model, classes, score_th, loss_th, save_path,
                Splicing_direction, save_picture, base_point, angle_use, d_frame, rc_th):
        self.thread2 = DemoThread()
        self.thread2.get_args(config, video_path, checkpoint, name_model, classes, score_th, loss_th, save_path,
                              Splicing_direction, save_picture, base_point, angle_use, d_frame, rc_th)
        self.thread2.change_value1.connect(self.setProgress1)
        self.thread2.change_value2.connect(self.setProgress2)
        self.thread2.change_value3.connect(self.setProgress3)
        self.thread2.start()

    def setProgress1(self, pgb_total, frame_id, imge_show, ww, hh):
        self.predict_button.setText('{} / {}'.format(frame_id, pgb_total))
        self.progress.setValue(100 * frame_id / pgb_total)
        # w_o = self.demo_result.geometry().width()
        # h_o = self.demo_result.geometry().height()

        # if self.combobox_direction.currentText() == '纵向拼接':
        #     imge_show = QPixmap(imge_show).scaled(int(386 * ww / hh), 386)
        # else:
        #     imge_show = QPixmap(imge_show).scaled(655, int(655 * hh / ww))
        if 655 / ww < 386 / hh:
            imge_show = QPixmap(imge_show).scaled(655, int(655 * hh / ww))
        else:
            imge_show = QPixmap(imge_show).scaled(int(386 * ww / hh), 386)
        self.demo_result.setPixmap(imge_show)

    def setProgress2(self, text):
        self.predict_button.setText(text)

    def setProgress3(self, total, the_num):
        self.progress.setValue(100 * the_num / total)

    # tab3槽函数：播放器的相关操作
    def playProgressSliderPressed(self):
        # 播放进度条按下ing事件
        if self.player.state() != 0:
            self.player.pause()

    def playProgressSliderReleased(self):
        # 播放进度条按下释放事件
        if self.player.state() != 0:
            self.player.setPosition(self.play_progress_slider.value())
            self.player.play()

    def playvideo(self):
        # 播放视频
        if self.player.duration() == 0: return
        self.play_btn.hide()
        self.pause_btn.show()
        self.player.play()

    def pausevideo(self):
        # 暂停视频
        if self.player.duration() == 0: return
        self.play_btn.show()
        self.pause_btn.hide()
        self.player.pause()

    def mute(self):
        # 禁音
        if self.player.isMuted():
            self.mute_btn.setIcon(QIcon(os.path.join(os.getcwd(), 'sound_on.png')))
            self.player.setMuted(False)
            self.volume_label.setText('50')
            self.volume_slider.setValue(50)
            self.player.setVolume(50)
        else:
            self.player.setMuted(True)
            self.volume_label.setText('0')
            self.volume_slider.setValue(0)
            self.mute_btn.setIcon(QIcon(os.path.join(os.getcwd(), 'sound_off.png')))

    def openvideo(self):
        # 打开并显示视频路径,'''打开视频文件'''
        fileName, _ = QFileDialog.getOpenFileName(self, 'Open File', '', 'MP4 Files (*.mp4)')
        if fileName:
            self.video_path.setText(fileName)
        # 将视频路径初始化进视频播放插件
        filepath = self.video_path.text()
        if not os.path.exists(filepath): return
        fileurl = QUrl.fromLocalFile(filepath)
        if fileurl.isValid():
            self.player.setMedia(QMediaContent(fileurl))
            self.player.setVolume(50)

    def setVolume(self):
        # 设置音量
        value = self.volume_slider.value()
        if value:
            self.player.setMuted(False)
            self.player.setVolume(value)
            self.volume_label.setText(str(value))
            self.volume_slider.setValue(value)
            self.mute_btn.setIcon(QIcon(os.path.join(os.getcwd(), 'sound_on.png')))
        else:
            self.player.setMuted(True)
            self.volume_label.setText('0')
            self.volume_slider.setValue(0)
            self.mute_btn.setIcon(QIcon(os.path.join(os.getcwd(), 'sound_off.png')))

    def setPlayProgress(self):
        # 播放进度设置
        _, right = self.play_progress_label.text().split('/')
        position = self.player.position() + 1
        second = int(position / 1000 % 60)
        minute = int(position / 1000 / 60)
        left = str(minute).zfill(2) + ':' + str(second).zfill(2)
        self.play_progress_label.setText(left + ' /' + right)
        self.play_progress_slider.setValue(position)

    def setVideoLength(self):
        # 视频时长显示更改
        left, _ = self.play_progress_label.text().split('/')
        duration = self.player.duration()
        self.play_progress_slider.setMaximum(duration)
        second = int(duration / 1000 % 60)
        minute = int(duration / 1000 / 60)
        right = str(minute).zfill(2) + ':' + str(second).zfill(2)
        self.play_progress_label.setText(left + '/ ' + right)


if __name__ == '__main__':
    multiprocessing.freeze_support()
    app = QApplication(sys.argv)
    demo = Demo()
    demo.show()
    app.exit(app.exec_())

